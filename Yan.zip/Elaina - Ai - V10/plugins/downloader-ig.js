import kode from 'kode-scrape'
const { downloader } = kode;

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command,
    text
}) => {
    let input = `[!] *Silakan Masukan Link Vidio/Foto Instagram*
	
Contoh : ${usedPrefix + command} https://www.instagram.com/reel/CsC2PQCNgM1/?igshid=NTc4MTIwNjQ2YQ==`
    if (!text) return m.reply(input)
    
    try {

        await m.reply('Tunggu Sebentar Kak🕒')
        let media = await downloader.instagram(text);
        for (let v of media) {
            await conn.sendFile(m.chat, v, '', null, m)
        }
    } catch (e) {
        throw msg.error
    }
}
handler.help = ["instagram"]
handler.tags = ['downloader']
handler.command = /^(instagram|igdl|ig|instagramdl)$/i
handler.limit = true
handler.register = true

export default handler