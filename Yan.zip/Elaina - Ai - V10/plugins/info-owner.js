const handler = async (m, { conn }) => {
  try {
    if (!global.config || !global.config.owner || !Array.isArray(global.config.owner)) {
      return conn.reply(m.chat, "⚠️ Tidak dapat menemukan daftar kontak owner!", m);
    }

    // Buat daftar kontak dalam format vCard
    let contacts = global.config.owner.map(([number, name]) => ({
      vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL;waid=${number}:${number}\nEND:VCARD`
    }));

    // Pastikan ada kontak yang tersedia
    if (contacts.length === 0) {
      return conn.reply(m.chat, "⚠️ Daftar kontak owner kosong!", m);
    }

    // Kirim daftar kontak ke pengguna
    await conn.sendMessage(m.chat, { contacts: { displayName: "Owner Bot", contacts } }, { quoted: m });

    // Kirim pesan mention setelah kontak dikirim
    await conn.sendMessage(
      m.chat,
      {
        text: `✨ Hai @${m.sender.split('@')[0]}, ini adalah owner ku yang siap membantu! 🐼🧡\n\n🔔 *Peringatan:* Mohon gunakan kontak ini seperlunya. Jangan spam, ya! 😊`,
        mentions: [m.sender]
      },
      { quoted: m }
    );

  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, "❌ Terjadi kesalahan saat mengirim kontak owner.", m);
  }
};

handler.help = ['owner'];
handler.tags = ['info'];
handler.command = /^(owner|creator)$/i;

export default handler;