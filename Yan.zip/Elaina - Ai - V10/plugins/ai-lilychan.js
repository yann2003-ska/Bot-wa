import fetch from 'node-fetch';

const handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) return m.reply(`Masukkan prompt!\nContoh: *${usedPrefix + command}* Apa itu ikan?`);
  
  conn.sendReact(m.chat, "⏳️", m.key); // Kirim reaksi loading
  
  try {
    // Ambil respons dari API
    const response = await fetch(`https://archive-ui.tanakadomp.biz.id/ai/lilychan?text=${encodeURIComponent(text)}`);
    let json = await response.json();

    // Periksa apakah respons API valid
    if (!json.status || !json.result) throw new Error("Gagal mendapatkan respons dari AI.");

    let hasil = json.result.message.trim() || 'Tidak ada respons.';

    // Kirim hasil dalam format teks tanpa gambar
    await conn.sendMessage(m.chat, { text: `*Lilychan AI :*\n${hasil}`.trim() });

  } catch (error) {
    console.error(error);
    await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` });
  }
};

handler.help = ['lilychan <prompt>'];
handler.tags = ['ai'];
handler.command = /^(lilychan)$/i;
handler.register = true;

export default handler;