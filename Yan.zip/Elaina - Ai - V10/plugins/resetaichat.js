let handler = async (m)  => {
   let ai = await fetch(`${config.api.xterm.url}/api/chat/logic-bell/reset?id=${m.sender}&key=${config.api.xterm.key}`)
        .then(response => response.json())
        m.reply(ai.msg)
}

handler.help = ["resetaichat"];
handler.tags = ["ai"];
handler.command = /^(resetaichat)$/i;

export default handler;