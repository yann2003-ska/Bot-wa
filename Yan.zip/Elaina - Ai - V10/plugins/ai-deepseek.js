import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw(`Contoh:\n${usedPrefix}${command} Halo?`);   
  let ouh = await fetch(`https://api.siputzx.my.id/api/ai/deepseek-r1?content=${text}`)
  let gyh = await ouh.json() 
  await conn.sendMessage(m.chat, {
  text: `${gyh.message}`,
      contextInfo: {
      externalAdReply: {
        title: 'Elaina - C.Ai',
        body: 'A I  -  D E E P S E E K',
        thumbnailUrl: 'https://files.catbox.moe/sjd280.jpg',
        sourceUrl: 'https://whatsapp.com/channel/0029VaicyTbAjPXOdW7P9f2x',
        mediaType: 1,
        renderLargerThumbnail: true, 
        showAdAttribution: true
      }}
  })}
handler.command = /^(depsek|depsek)$/i
handler.help = ['depsek']
handler.tags = ['ai']
handler.limit = true
handler.onlyprem = true

export default handler;