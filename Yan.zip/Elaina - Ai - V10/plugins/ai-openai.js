import fetch from "node-fetch";

const handler = async (m, { text, usedPrefix, command, conn }) => {
  try {
    if (!text) {
      throw new Error("Masukkan pertanyaan!\n\n*Contoh:* ai hai");
    }

    // Kirim reaksi "🕒" untuk menunjukkan bahwa proses sedang berjalan
    await conn.sendReact(m.chat, "🕒", m.key);

    // Buat URL API dengan parameter prompt dan content yang sudah ditentukan
    const prompt = "kamu adalah ai yang ceria";
    const url = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(prompt)}&content=${encodeURIComponent(text)}`;

    // Lakukan request GET ke API
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0",
      },
    });

    if (!response.ok) {
      throw new Error(`Request gagal dengan status: ${response.status} - ${response.statusText}`);
    }

    const result = await response.json();

    // Periksa respons apakah statusnya true dan data ada
    if (!result.status || !result.data) {
      throw new Error(`Respons API tidak valid: ${JSON.stringify(result)}`);
    }

    // Kirim pesan hasil ke pengguna
    await conn.sendMessage(m.chat, {
      text: result.data,
    });

  } catch (error) {
    console.error("Error pada handler:", error.message);
    await conn.sendMessage(m.chat, {
      text: `❌ Error: ${error.message}`,
    });
  }
};

// Properti tambahan untuk handler
handler.help = ['ai <pertanyaan>'];
handler.tags = ['ai'];
handler.command = /^(ai)$/i;

handler.limit = 6;
handler.premium = false;
handler.register = true;

export default handler;