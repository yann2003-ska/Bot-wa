/*
 • Fitur By Anomaki Team
 • Created : xyzan code
 • Download Tiktok
 • Scrape : ZEvrida (Thanks 😍)
 • Jangan Hapus Wm
 • https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l

- *--Image (gambar/vt slide)*
- *--video (Video Tiktok)*
- *--audio (Audio)*

Dan bisa digabung, Slide & Sound dl, Video & Sound Dl.  bisa skrepnya. 
*/

import fetch from "node-fetch";

async function dapatkanVideo(url) {
    try {
        const response = await fetch('https://lovetik.com/api/ajax/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
            body: `query=${encodeURIComponent(url)}`
        });

        const data = await response.json();
        if (!data.images) data.images = [];

        const result = {
            video: [],
            audio: [],
            images: data.images || []
        };

        data.links.forEach(item => {
            if (!item.a) return;
            const formatted = {
                format: item.t.replace(/<.*?>|♪/g, '').trim(),
                resolution: item.s || 'Audio Only',
                link: item.a
            };

            if (item.ft == 1) {
                result.video.push(formatted);
            } else {
                result.audio.push(formatted);
            }
        });

        data.render = async () => {
            const rendered = await fetch('https://lovetik.com/api/ajax/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                },
                body: `c_data=${encodeURIComponent(data.links.filter(m => m.c)[0].c)}`
            });
            return rendered.json();
        };

        return {
            ...data,
            ...result
        };
    } catch (error) {
        console.error("Error mengambil video:", error);
        return null;
    }
}

var handler = async (m, {
    text,
    conn
}) => {
    if (!text) return conn.sendMessage(m.chat, {
        text: "Masukkan URL video TikTok beserta opsi (--image, --audio, --video)."
    }, {
        quoted: m
    });

    let args = text.split(" ");
    let url = args.find(arg => arg.startsWith("http"));
    let option = args.find(arg => ["--image", "--audio", "--video"].includes(arg));

    if (!url) return conn.sendMessage(m.chat, {
        text: "URL tidak ditemukan. Masukkan URL TikTok yang valid."
    }, {
        quoted: m
    });
    if (!option) return conn.sendMessage(m.chat, {
        text: "pilih opsi:\n• --audio\n• --video\n• --image."
    }, {
        quoted: m
    });

    let result = await dapatkanVideo(url);
    if (!result) return conn.sendMessage(m.chat, {
        text: "Gagal mengambil data."
    }, {
        quoted: m
    });

    if (option === "--image") {
        if (!result.images.length) return conn.sendMessage(m.chat, {
            text: "Gambar tidak ditemukan."
        }, {
            quoted: m
        });
        for (let img of result.images) {
            await conn.sendMessage(m.chat, {
                image: {
                    url: img
                },
                caption: "done"
            }, {
                quoted: m
            });
        }
    } else if (option === "--audio") {
        if (!result.audio.length) return conn.sendMessage(m.chat, {
            text: "Audio tidak ditemukan."
        }, {
            quoted: m
        });
        await conn.sendMessage(m.chat, {
            audio: {
                url: result.audio[0].link
            },
            mimetype: "audio/mp4",
            ptt: false
        }, {
            quoted: m
        });
    } else if (option === "--video") {
        if (!result.video.length) return conn.sendMessage(m.chat, {
            text: "Video tidak ditemukan."
        }, {
            quoted: m
        });
        await conn.sendMessage(m.chat, {
            video: {
                url: result.video[0].link
            },
            caption: "done"
        }, {
            quoted: m
        });
    }
};

handler.command = handler.help = ["tt2","tiktok2"];
handler.tags = ["downloader"];
handler.register = true;
handler.limit = true;

export default handler;