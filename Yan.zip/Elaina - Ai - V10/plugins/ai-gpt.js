import fetch from 'node-fetch';

const handler = async (m, { conn, text, quoted }) => {
  // Validasi input
  if (!text) {
    return m.reply('Silakan masukkan teks yang ingin Anda tanyakan.');
  }

  try {
    // Jika user mereply pesan bot
    let context = '';
    if (quoted) {
      context = quoted.text || ''; // Menggunakan teks dari pesan yang direply sebagai konteks
    }

    // Gabungkan konteks (jika ada) dengan input user
    const query = encodeURIComponent(`${context.trim()} ${text.trim()}`);
    const url = `https://api.agatz.xyz/api/gptlogic?logic=Generate humanized chatgpt text in Indonesian, you are an AI assistant named Farid&p=${query}`;
    
    // Panggil API GPT Logic
    const response = await fetch(url);
    const json = await response.json();

    if (json.status === 200 && json.data?.result) {
      const replyText = json.data.result;
      // Kirim balasan dengan teks hasil dari GPT Logic
      await conn.sendMessage(m.chat, { text: replyText }, { quoted: m });
    } else {
      m.reply('Terjadi kesalahan saat memproses permintaan. Silakan coba lagi nanti.');
    }
  } catch (error) {
    console.error('Error GPT Logic:', error);
    m.reply('Terjadi kesalahan saat menghubungi API. Silakan coba lagi nanti.');
  }
};

handler.help = ['gpt <pertanyaan>'];
handler.tags = ['gpt'];
handler.command = /^(gpt)$/i;

handler.limit = 6;
handler.premium = false;
handler.register = true;

export default handler;