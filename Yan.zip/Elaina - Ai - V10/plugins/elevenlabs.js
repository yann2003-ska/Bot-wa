const handler = async (m, { conn, text }) => {
  
  
        let [voice,txt] = text.split("|")
        let voices = ["prabowo","bella","echilling","adam"]
        let txtreply = `\`LIST VOICES\`
- prabowo
- yanzgpt
- bella
- megawati
- echilling
- adam
- thomas_shelby
- michi_jkt48
- nokotan
- jokowi
- boboiboy
- keqing
- anya
- yanami_anna
- MasKhanID
- Myka`
        if(!voices.includes(voice)) return m.reply(txtreply)
        if(!txt) return m.reply(txtreply)
        await conn.sendPresenceUpdate('recording', m.chat);
        conn.sendMessage(m.chat, { audio: { url: `${config.api.xterm.url}/api/text2speech/elevenlabs?voice=${voice}&key=${config.api.xterm.key}&text=${txt}`}, mimetype: "audio/mpeg", ptt: true }, { quoted: m })
	
}

handler.help = ['elevenlabs voice|text']
handler.tags = ['ai']
handler.command = ["elevenlabs"]
handler.limit = true
handler.premium = false

export default handler