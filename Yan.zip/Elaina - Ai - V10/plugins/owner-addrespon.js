import fs from "fs"

let resp = "./lib/response/"
let handler = async(m, { conn, command,text }) => {
  let lists = await fs.readdirSync(resp)
  if (!m.quoted) return m.reply("Reply pesan nya!")
  if(command == "addrespon"){
      if(!text) return m.reply("Sertakan teks!, contoh: .delrespon .menu")
        let r = JSON.stringify(m.message.extendedTextMessage.contextInfo.quotedMessage, null, 2)
        await fs.writeFileSync(resp + text, r)
        m.reply(`Berhasil Menambahkan respon "${text}"!`)
  } else {
        if(!text) return m.reply("Sertakan teks!, contoh: .delrespon .menu")
        if(!lists.includes(text)) return m.reply(`Respon untuk pesan "${text}" tidak tersedia!`)
        await fs.unlinkSync(resp + text)
        m.reply(`Berhasil menghapus respon "${text}"`)
  }
}

handler.help = ["addrespon <text>","delrespon"]
handler.tags = ["owner"]
handler.owner = true
handler.command = /^(addrespon|delrespon)/i

export default handler