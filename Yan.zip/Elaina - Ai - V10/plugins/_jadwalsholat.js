import { JadwalSholat } from '../lib/jadwalsholat.js'

const on = (cmd, input) => `Berhasil ${cmd == "on" ? "mengaktifkan":"menonaktifkan"} *${input}* di group ini!`

const dateFormatter = (time, timezone) => {
  const validTimezones = ['Asia/Jakarta', 'Asia/Makassar', 'Asia/Jayapura']
  if (!validTimezones.includes(timezone)) {
       return `Timezone invalid!, Look this: ${validTimezones.join(", ")}`
  }
  const options = { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }
  const formatter = new Intl.DateTimeFormat('en-GB', options)
  const parts = formatter.formatToParts(new Date(time))

  const day = parseInt(parts.find(part => part.type === 'day').value, 10);
  const month = parts.find(part => part.type === 'month').value
  const year = parts.find(part => part.type === 'year').value
  const hours = parts.find(part => part.type === 'hour').value
  const minutes = parts.find(part => part.type === 'minute').value
  const seconds = parts.find(part => part.type === 'second').value

  const formattedDate = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`
  return formattedDate
} 

let handler = async (m, { text, usedPrefix, command }) => {
  let [_a,_b,...etc] = text.split(" ")
  let txt = `*MAU LIHAT JADWAL ATAU AKTIFIN AUTO SHOLATNYA?*
  
 •> \`Untuk melihat jadwal\`
- lihat 
- view
> Contoh: .jadwalsholat lihat kab-bungo

 •> \`Untuk mengaktifkan/menonaktifkan auto sholat\`
- on
- off

- Contoh: ${'.' + command +' on kab-bungo'}

_Anda juga bisa menyertakan type di sebelah input daerah untuk kebutuhan tertentu_

\`List type:\`
- ramadhan
> Untuk bulan ramadhan, ini akan sekaligus mengingatkan waktu imsak dan ucapan selamat berbuka saat adzan Maghrib berkumandang
- tutup
> otomatis menutup grup(selama 5 menit) saat tiba waktu sholat

- Contoh penggunaan type: .on on kab-bungo ramadhan tutup

_Jika sudah mengaktifkan jadwalsholat dengan tipe diatas, anda bisa memastikannya dengan .jadwalsholat off lalu meng-aktifkan kembali .jadwalsholat on daerah tanpa menyertakan type_

> *❗Dengan teks ini, admin sangat berharap kepada user untuk membaca dengan teliti agar tidak menanyakan lagi!*
`
  if(!_a) return m.reply(txt)
  if(['lihat','view'].includes(_a)){
    let { status, data, msg, timeZone, list } = await jadwal.init('no', _b)
    if(!status) return m.reply(`*${msg}*${list ? `\n\nList daerah:\n- ${list.join('\n- ')}`:''}`)
  
    const formatter = new Intl.DateTimeFormat('id-ID', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    })
 
    const parts = formatter.formatToParts(new Date())
    const d = parseInt(parts.find(p => p.type === 'day').value, 10);
    const _m = parts.find(p => p.type === 'month').value

    let dm = `${d}/${_m}`
    let a = data.find(a => a.tanggal == dm)
    let _text = `*JADWAL SHOLAT*\n\nHari ini: *${dateFormatter(Date.now(), timeZone)}*\n- imsak: ${a.imsak}\n- subuh: ${a.subuh}\n- dzuhur: ${a.dzuhur}\n- ashar: ${a.ashar}\n- magrib: ${a.magrib}\n- isya: ${a.isya}\n\n*Jadwal bulan ini*:\n${"͏".repeat(3646)}\n${data.map(a => ` \n 🗓️ \`${a.tanggal}\`\n- imsak: ${a.imsak}\n- subuh: ${a.subuh}\n- dzuhur: ${a.dzuhur}\n- ashar: ${a.ashar}\n- magrib: ${a.magrib}\n- isya: ${a.isya}\n`).join('\n')}`
    m.reply(_text)
  } else if(['off','on'].includes(_a)){
    let sholat = {}
    if(_a == 'on'){
      if(global.db.data.chats[m.chat].jadwalsholat) return m.reply("Sudah aktif disini!")
      if(!_b) return m.reply(`*Harap sertakan daerahnya!*
- Contoh: ${'.' + command +' on kab-bungo'}

_Anda juga bisa menyertakan type di sebelah input daerah untuk kebutuhan tertentu_

\`List type:\`
- ramadhan
> Untuk bulan ramadhan, ini akan sekaligus mengingatkan waktu imsak dan ucapan selamat berbuka saat adzan Maghrib berkumandang
- tutup
> otomatis menutup grup(selama 5 menit) saat tiba waktu sholat

- Contoh penggunaan type: .on on kab-bungo ramadhan tutup

_Jika sudah mengaktifkan jadwalsholat dengan tipe diatas, anda bisa memastikannya dengan .jadwalsholat off lalu meng-aktifkan kembali .jadwalsholat on daerah tanpa menyertakan type_

> *❗Dengan teks ini, admin sangat berharap kepada user untuk membaca dengan teliti agar tidak menanyakan lagi!*`)
          let isOpt = false
          if(etc.length > 0){
            let acts = ['ramadhan', 'tutup']
            let notf = etc.find(a => !acts.includes(a))
            if(notf) return m.reply(`Pilihan opsi ${notf} tidak tersedia!\n\nOpsi yang tersedia: ${acts.join(', ')}`)
            isOpt = true
          }
          let _txt = `${on(_a, command)}`
          if(isOpt){
            _txt += `\n\n\`Type\`:`
            for(let i of etc){
              _txt += `\n- ${i}`
              sholat[i] = true
            }
          }
          let { status, msg, data, list, db } = await jadwal.init(m.chat, _b, sholat)
          if(!status) return m.reply(`*${msg}*${list ? `\n\nList daerah:\n- ${list.join('\n- ')}`:''}`)
          global.db.data.chats[m.chat].jadwalsholat = db
          jadwal.groups[m.chat] = db
          return await m.reply(_txt)
      } else if(_a == 'off'){
        if(!global.db.data.chats[m.chat].jadwalsholat) return m.reply("Sudah non-aktif disini!")
        delete global.db.data.chats[m.chat].jadwalsholat
        delete jadwal.groups[m.chat]
        await m.reply(on(_a, command))
      }
  } else m.reply(txt)
 
}

handler.help = ['jadwsholat'].map(v => v + ' <daerah>')
handler.tags = ['quran']
handler.command = /^(jadwal)?s(a|o|ha|ho)lat$/i
export default handler