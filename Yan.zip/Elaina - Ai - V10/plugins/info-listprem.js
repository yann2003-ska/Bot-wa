let handler = async (m, { conn, args, text, usedPrefix, command, isOwner, isAdmin }) => {
  // Mendapatkan database pengguna
  let userDb = global.db.data.users;

  // Pastikan database pengguna valid
  if (!userDb) {
    return conn.reply(m.chat, `⚠️ Database pengguna tidak ditemukan!`, m);
  }

  // Filter pengguna premium
  let premiumUsers = Object.entries(userDb)
    .filter(([_, value]) => value.premium && value.premiumTime > Date.now())
    .map(([key, value]) => ({ ...value, jid: key }));

  // Jika tidak ada pengguna premium
  if (premiumUsers.length === 0) {
    return conn.reply(m.chat, `⚠️ Tidak ada pengguna premium yang aktif!`, m);
  }

  // Urutkan pengguna premium berdasarkan waktu habis
  let sortedP = premiumUsers.sort((a, b) => a.premiumTime - b.premiumTime);

  // Jika argumen kosong, tampilkan daftar pengguna premium
  if (!args[0]) {
    let premiumList = sortedP.map(({ jid, premiumTime }, i) => {
      return `${i + 1}. @${jid.split('@')[0]} \n- (Sisa: ${clockString(premiumTime - Date.now())})`;
    }).join('\n');

    return conn.reply(
      m.chat,
      `╭─❏ *LIST PREMIUM USER* ❏─\n${premiumList}\n╰─────────────────`,
      m,
      { mentions: sortedP.map(user => user.jid) }
    );
  }

  // Validasi nomor indeks jika ada argumen
  let index = parseInt(args[0]) - 1; // Indeks dari argumen pertama
  if (isNaN(index) || index < 0 || index >= sortedP.length) {
    return conn.reply(m.chat, `⚠️ Nomor tidak valid dalam daftar premium!`, m);
  }

  // Ambil pengguna target berdasarkan indeks
  let targetUser = sortedP[index];
  let targetJid = targetUser?.jid;

  if (!targetJid) {
    return conn.reply(m.chat, `⚠️ Pengguna tidak ditemukan!`, m);
  }

  // Aksi untuk delprem atau pengurangan waktu
  let action = args[1];
  switch (action) {
    case 'delprem': {
      // Hapus status premium pengguna
      userDb[targetJid].premium = false;
      userDb[targetJid].premiumTime = 0;

      return conn.reply(
        m.chat,
        `✔️ Berhasil menghapus @${targetJid.split('@')[0]} dari premium.`,
        m,
        { mentions: [targetJid] }
      );
    }
    default: {
      // Kurangi waktu premium jika argumen valid
      let timeToDeduct = parseDuration(action);
      if (timeToDeduct) {
        userDb[targetJid].premiumTime = Math.max(userDb[targetJid].premiumTime - timeToDeduct, 0);

        // Hapus status premium jika masa aktif habis
        if (userDb[targetJid].premiumTime <= Date.now()) {
          userDb[targetJid].premium = false;
        }

        return conn.reply(
          m.chat,
          `✔️ Berhasil mengurangi masa aktif @${targetJid.split('@')[0]} sebanyak ${clockString(
            timeToDeduct
          )}.`,
          m,
          { mentions: [targetJid] }
        );
      } else {
        return conn.reply(
          m.chat,
          `⚠️ Format waktu tidak valid! Gunakan format seperti *1y*, *1M*, *1w*, *1d*, *1h*, atau *1m*.`,
          m
        );
      }
    }
  }
};

// Fungsi untuk mengubah milidetik menjadi string waktu
function clockString(ms) {
  let y = Math.floor(ms / 31536000000); // Tahun
  let M = Math.floor(ms / 2592000000) % 12; // Bulan
  let w = Math.floor(ms / 604800000) % 4; // Minggu
  let d = Math.floor(ms / 86400000) % 7; // Hari
  let h = Math.floor(ms / 3600000) % 24; // Jam
  let m = Math.floor(ms / 60000) % 60; // Menit
  return `${y > 0 ? `${y}y ` : ''}${M > 0 ? `${M}M ` : ''}${w > 0 ? `${w}w ` : ''}${d > 0 ? `${d}d ` : ''}${h}h ${m}m`;
}

// Fungsi untuk mengubah input waktu menjadi milidetik
function parseDuration(input) {
  let matches = input.match(/^(\d+)([yMwdhm])$/i);
  if (!matches) return null;

  let value = parseInt(matches[1]);
  let unit = matches[2].toLowerCase();

  let multiplier =
    unit === 'y' ? 31536000000 : // Tahun
    unit === 'M' ? 2592000000 :  // Bulan
    unit === 'w' ? 604800000 :   // Minggu
    unit === 'd' ? 86400000 :    // Hari
    unit === 'h' ? 3600000 :     // Jam
    60000;                       // Menit

  return value * multiplier;
}

handler.help = ['listprem [nomor] [aksi]'];
handler.tags = ['owner'];
handler.command = /^(listprem|premlist)$/i;

export default handler;