let handler = async (m, { conn, command }) => {
	const listGroup = Object.values(await conn.groupFetchAllParticipating().catch(() => ({})));
	if (listGroup.length < 1) throw "Belum ada grup yg saya masuki!";
	if (/no/.test(command)) {
		let txt = `*LIST NO SEWA:*\n\n`;
		for (const { id, subject, size } of listGroup) {
			if (!id && !subject) continue;
			const chat = id in global.db.data.chats && global.db.data.chats[id];
			const expired = chat && chat?.expired && chat.expired > 0 ? true : false;
			if (expired) continue;
			txt += `• ID: ${id}\n`;
			txt += `• Name: ${subject}\n`;
			txt += `• Size: ${size}\n`;
			txt += "\n";
		};
		
		m.reply(txt.trim());
	} else {
		let txt = `*LIST SEWA:*\n\n`;
		for (const { id, subject, size } of listGroup) {
			if (!id && !subject) continue;
			const chat = id in global.db.data.chats && global.db.data.chats[id];
			const expired = chat && chat?.expired && chat.expired > 0 ? (chat.expired - Date.now()).toTimeString() : "PERMANENT";
			txt += `• ID: ${id}\n`;
			txt += `• Name: ${subject}\n`;
			txt += `• Expired: ${expired}\n`;
			txt += `• Size: ${size}\n`;
			txt += "\n";
		};
		
		m.reply(txt.trim());
	};
};

handler.help = ["sewa", "nosewa"].map(v => "list" + v);
handler.tags = ["owner", "info"];
handler.command = /^list(no)?sewa$/i;
handler.owner = true

export default handler;