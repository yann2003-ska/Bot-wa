import fs from 'fs';
import fetch from "node-fetch";
import crypto from "crypto";
import { FormData, Blob } from "formdata-node";
import { fileTypeFromBuffer } from "file-type";

const clanFile = './clan.json';

// Memastikan file JSON ada, jika tidak, buat file dengan data default
const initializeClanFile = () => {
  if (!fs.existsSync(clanFile)) {
    const defaultData = { clans: {}, members: {} };
    fs.writeFileSync(clanFile, JSON.stringify(defaultData, null, 2));
    console.log('File clan.json telah dibuat dengan data default.');
  }
};

// Fungsi untuk memuat data klan dari file
const loadClan = () => {
  try {
    const data = fs.readFileSync(clanFile);
    const parsedData = JSON.parse(data);

    // Memastikan setiap klan memiliki data default jika belum ada
    for (const clanId in parsedData.clans) {
      if (!parsedData.clans[clanId].resources) {
        parsedData.clans[clanId].resources = { wood: 0, iron: 0, diamond: 0, rock: 0, coal: 0, string: 0 };
      }
      if (!parsedData.clans[clanId].artifacts) {
        parsedData.clans[clanId].artifacts = { grimoire: 0, scepter: 0, crown: 0, gemstone: 0, cloak: 0, spear: 0 };
      }
      if (!parsedData.clans[clanId].defenseLevel) parsedData.clans[clanId].defenseLevel = 1;
      if (!parsedData.clans[clanId].attackLevel) parsedData.clans[clanId].attackLevel = 1;
      if (!parsedData.clans[clanId].exp) parsedData.clans[clanId].exp = 0;
      if (!parsedData.clans[clanId].level) parsedData.clans[clanId].level = 1;
      if (!parsedData.clans[clanId].aegis) parsedData.clans[clanId].aegis = 50;
      if (!parsedData.clans[clanId].basics) parsedData.clans[clanId].basics = 25;
      if (!parsedData.clans[clanId].activityLog) parsedData.clans[clanId].activityLog = [];
      if (!parsedData.clans[clanId].settings) parsedData.clans[clanId].settings = { approval: false };
      if (!parsedData.clans[clanId].bank) parsedData.clans[clanId].bank = 0;
      if (!parsedData.clans[clanId].profile) parsedData.clans[clanId].profile = null;
      if (!parsedData.clans[clanId].transferHistory) parsedData.clans[clanId].transferHistory = {};
      if (!parsedData.clans[clanId].officers) parsedData.clans[clanId].officers = [];
    }

    return parsedData;
  } catch (err) {
    console.error('Gagal membaca file clan.json. Mulai dengan data kosong.');
    return { clans: {}, members: {} };
  }
};

// Menyimpan data ke clan.json
const saveClan = (data) => {
  try {
    fs.writeFileSync(clanFile, JSON.stringify(data, null, 2));
    console.log('Data clan berhasil disimpan.');
  } catch (err) {
    console.error('Gagal menyimpan data clan:', err);
  }
};

// Inisialisasi file clan.json
initializeClanFile();

// Data clan di-load saat server dimulai
let { clans, members } = (() => {
  const data = loadClan();
  return { clans: data.clans, members: data.members };
})();

// Fungsi untuk mencatat aktivitas
const logActivity = (clanId, message) => {
  if (!clans[clanId]) return;
  if (!clans[clanId].activityLog) clans[clanId].activityLog = [];
  clans[clanId].activityLog.push({
    message,
    timestamp: Date.now(),
  });
  if (clans[clanId].activityLog.length > 100) {
    clans[clanId].activityLog.shift(); // Batasi log hingga 100 entri
  }
  saveClan({ clans, members });
};

// Handler utama
let handler = async (m, { text, args, command, isOwner }) => {
  const sender = m.sender;

  if (!args[0]) {
    return m.reply(`
\`F E A T U R E   C L A N\`

*A. Manajemen Clan*
1. *clan create <name>*  
   ╰╼ Membuat clan baru.  
2. *clan profile*  
   ╰╼ Menampilkan profil clan.  
3. *clan private on/off*  
   ╰╼ Mengatur privasi clan agar orang lain tidak bisa masuk.  
4. *clan setprofile*  
   ╰╼ Menambahkan gambar di profil clan.  
5. *clan delprofile*  
   ╰╼ Menghapus gambar di profil clan.  
6. *clan leaderboard*  
   ╰╼ Menampilkan peringkat top clan.  

*B. Keanggotaan Clan*
1. *clan join <id>*  
   ╰╼ Bergabung dengan clan.  
2. *clan out*  
   ╰╼ Keluar dari clan.  
3. *clan kick <memberid>*  
   ╰╼ Mengeluarkan anggota dari clan.  
4. *clan member*  
   ╰╼ Melihat daftar anggota clan.  
5. *clan owner @tag*  
   ╰╼ Mentransfer kepemilikan clan.
6. *clan promote @tag*  
   ╰╼ Angkat anggota ke officer.  
7. *clan demote @tag*  
   ╰╼ Turunkan officer ke anggota.  

*C. Perang dan Pertahanan*
1. *clan war <id>*  
   ╰╼ Menantang clan lain untuk perang.  
2. *clan repair*  
   ╰╼ Memperbaiki pertahanan yang rusak.  
3. *clan up <type>*  
   ╰╼ Upgrade pertahanan atau serangan clan.  

*D. Aktivitas dan Ekonomi Clan*
1. *clan jelajah*  
   ╰╼ Mencari bahan (wood, iron, diamond, dll).  
2. *clan shop buy <barang> <jumlah>*  
   ╰╼ Membeli bahan untuk clan.  
3. *clan transfer <id clan> <item> <jumlah>*  
   ╰╼ Mentransfer barang ke clan lain.  
4. *clan activity*  
   ╰╼ Menampilkan aktivitas seluruh anggota clan.  
5. *clan dungeon*  
   ╰╼ Menjelajahi dungeon untuk mendapatkan reward.  
6. *clan nebang*  
   ╰╼ Menebang kayu. 

*E. Informasi dan Lainnya*
1. *clan list*  
   ╰╼ Menampilkan daftar clan yang ada.
    `.trim());
  }

  const subCommand = args[0]?.toLowerCase();

  switch (subCommand) {
    case 'create': {
      if (members[sender]) throw 'Kamu sudah berada di sebuah clan.';

      // Check if user has enough money
      const userMoney = global.db.data.users[sender].eris;
      const clanCreationCost = 2500000; // 2.5 million money

      if (userMoney < clanCreationCost) throw 'Uangmu tidak cukup untuk membuat clan. Biaya pembuatan clan adalah 2.5 juta.';

      // Deduct the money from the user's balance
      global.db.data.users[sender].eris -= clanCreationCost;

      const clanName = args.slice(1).join(' ');

      // Validate clan name length
      if (!clanName) throw 'Nama clan harus diisi.\n> contoh: .clan create Clan Uchiha';
      if (clanName.length < 3) throw 'Nama clan harus lebih dari 3 huruf.';
      if (clanName.length > 16) throw 'Nama clan tidak boleh lebih dari 16 huruf.';

      const clanId = Math.random().toString(36).slice(2, 8);
      clans[clanId] = {
        id: clanId,
        name: clanName,
        owner: sender, // Owner ditentukan saat pembuatan
        members: [sender],
        resources: { wood: 0, iron: 0, diamond: 0, rock: 0, coal: 0, string: 0 },
        artifacts: { grimoire: 0, scepter: 0, crown: 0, gemstone: 0, cloak: 0, spear: 0 },
        defenseLevel: 1,
        attackLevel: 1,
        exp: 0,
        level: 1,
        aegis: 50,
        basics: 25,
        activityLog: [],
        settings: { approval: false },
        bank: 0,
        profile: null,
        officers: [],
        transferHistory: {}
      };

      members[sender] = clanId;
      logActivity(clanId, `Clan "${args[1] || 'Tanpa Nama'}" berhasil dibuat oleh ${global.db.data.users[sender]?.name || sender}.`);
      saveClan({ clans, members });
      m.reply(`Berhasil dibuat\n\nClan: ${clanName}\nID: ${clanId}\nBiaya pembuatan: 2.5 juta telah dipotong dari uangmu.`);
      break;
    }
    case 'profile': {
  if (!members[sender]) {
    throw 'Kamu belum bergabung dengan clan.\nCari atau buat clan terlebih dahulu.';
  }

  // Ambil ID clan dan data clan pengguna
  const clanIdForProfile = members[sender];
  const clanForProfile = clans[clanIdForProfile];

  // Hitung statistik maksimal berdasarkan level
  const maxDefense = clanForProfile.defenseLevel * 50;
  const maxAttack = clanForProfile.attackLevel * 25;

  // Ambil nama pemilik clan
  const ownerName = global.db.data.users[clanForProfile.owner]?.name || 'Tidak diketahui';

  // Daftar anggota clan
  const memberNames = clanForProfile.members
    .map(memberId => {
      const userName = global.db.data.users[memberId]?.name || 'Tidak diketahui';
      return `- ${userName}`;
    })
    .join('\n');

  // Daftar officer clan
  const officerNames = clanForProfile.officers.length > 0
    ? clanForProfile.officers
        .map(officerId => {
          const officerName = global.db.data.users[officerId]?.name || 'Tidak diketahui';
          return `- ${officerName}`;
        })
        .join('\n')
    : 'Tidak ada officer.';

  // Daftar artefak dengan emoji
  const artifactEmojis = {
    grimoire: '📜 Grimoire',
    scepter: '⚡ Scepter',
    crown: '👑 Crown',
    gemstone: '💎 Gemstone',
    cloak: '🧥 Cloak',
    spear: '⚔️ Spear',
  };

  // Menggabungkan daftar artefak yang aktif dalam jumlah
  const artifacts = clanForProfile.artifacts || { grimoire: 0, scepter: 0, crown: 0, gemstone: 0, cloak: 0, spear: 0 };
  const artifactList = Object.keys(artifacts)
    .filter(artifact => artifacts[artifact] > 0) // Hanya tampilkan artefak dengan jumlah lebih dari 0
    .map(artifact => `${artifactEmojis[artifact]} x${artifacts[artifact]}`)
    .join('\n') || 'Tidak ada artefak.';

  // Format pesan profil clan
  const profileCaption = `\`C L A N   P R O F I L E\`\n
- 🏷️ Name: ${clanForProfile.name}
- 🆔 ID: ${clanForProfile.id}
- 👑 Owner: ${ownerName}

- 🎖️ Officers (${clanForProfile.officers.length} | 3):\n${officerNames}

- 👥 Members (${clanForProfile.members.length} | 15):\n${memberNames}

- 📦 Resources:
    🌲 Wood: ${clanForProfile.resources.wood}
    ⛏️ Iron: ${clanForProfile.resources.iron}
    💎 Diamond: ${clanForProfile.resources.diamond}
    🪨 Rock: ${clanForProfile.resources.rock}
    🖤 Coal: ${clanForProfile.resources.coal}
    🧵 String: ${clanForProfile.resources.string}
    
- 🏺 Artefak:\n${artifactList}
  
- 🛡️ Defense: Level ${clanForProfile.defenseLevel}
      ╰╼ 🌀 Aegis: ${clanForProfile.aegis} | ${maxDefense}
- ⚔️ Attack: Level ${clanForProfile.attackLevel}
      ╰╼ 🔪 Basics: ${clanForProfile.basics} | ${maxAttack}
      
- 📈 Exp: ${clanForProfile.exp} / ${clanForProfile.level * 1000}
- 🔥 Level Clan: ${clanForProfile.level}
- 🏦 Bank: Cp. ${clanForProfile.bank}
- 🔒 Private: ${clanForProfile.settings.approval ? 'ON' : 'OFF'}`.trim();

  // Kirim pesan dengan gambar jika tersedia
  if (clanForProfile.profile) {
    await conn.sendMessage(
      m.chat,
      {
        image: { url: clanForProfile.profile },
        caption: profileCaption,
      },
      { quoted: m }
    );
  } else {
    // Kirim pesan teks jika tidak ada gambar
    m.reply(profileCaption);
  }

  break;
}

    case 'jelajah': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForJelajah = members[sender];
  const clanForJelajah = clans[clanIdForJelajah];

  // Cek apakah pengguna sedang dalam cooldown
  const lastJelajahTime = clanForJelajah.memberCooldowns?.[sender] || 0;
  const cooldownTime = 15 * 60 * 1000; // 15 menit dalam milidetik
  const currentTime = Date.now();

  if (currentTime - lastJelajahTime < cooldownTime) {
    const remainingTime = Math.ceil((cooldownTime - (currentTime - lastJelajahTime)) / 60000);
    throw `Kamu harus menunggu ${remainingTime} menit lagi sebelum dapat melakukan jelajah lagi.`;
  }

  // Update waktu terakhir jelajah untuk member
  clanForJelajah.memberCooldowns = clanForJelajah.memberCooldowns || {};
  clanForJelajah.memberCooldowns[sender] = currentTime;

  // Mendapatkan semua resource dengan jumlah acak
  const resources = ['wood', 'iron', 'diamond', 'rock', 'coal', 'string'];
  
  // Menentukan jumlah bahan yang ditemukan secara acak untuk setiap resource
  let foundResources = {};
  const levelMultiplier = 1 + (clanForJelajah.level * 0.5); // Pengali berdasarkan level clan (50% per level)

  resources.forEach(resource => {
    const baseAmount = Math.floor(Math.random() * 10) + 1; // Mendapatkan 1-10 bahan untuk setiap resource
    foundResources[resource] = Math.ceil(baseAmount * levelMultiplier); // Pendapatan dengan pengali
  });

  // Menghitung pendapatan berdasarkan uang di bank
  const bank = clanForJelajah.bank;
  let minIncome = 10, maxIncome = 15;
  if (bank >= 1000) {
    minIncome = 15;
    maxIncome = 30;
  }
  if (bank >= 5000) {
    minIncome = 30;
    maxIncome = 50;
  }

  const income = Math.ceil((Math.random() * (maxIncome - minIncome + 1) + minIncome) * levelMultiplier);
  clanForJelajah.bank += income; // Menambahkan pendapatan ke bank clan

  // Menambahkan bahan yang ditemukan ke resources clan
  resources.forEach(resource => {
    clanForJelajah.resources[resource] += foundResources[resource];
  });

  // Menambahkan EXP ke clan setelah jelajah
  const baseExp = Math.floor(Math.random() * 10) + 5; // EXP yang diperoleh antara 5 hingga 15
  const expGained = Math.ceil(baseExp * levelMultiplier); // EXP dengan pengali
  clanForJelajah.exp += expGained;

  // Hitung kebutuhan EXP untuk level berikutnya
  const requiredExp = clanForJelajah.level * 1000;

  // Periksa apakah clan naik level
  if (clanForJelajah.exp >= requiredExp) {
    clanForJelajah.exp -= requiredExp; // Sisa EXP diteruskan ke level berikutnya
    clanForJelajah.level++; // Naik level
  }

  m.reply(`\`C L A N   R E S O U R C E S\`\n\n
- 🌲 Wood: ${foundResources.wood}  
- ⛏️ Iron: ${foundResources.iron}  
- 💎 Diamond: ${foundResources.diamond}  
- 🪨 Rock: ${foundResources.rock}  
- 🖤 Coal: ${foundResources.coal}  
- 🧵 String: ${foundResources.string}  

💰 Kamu juga mendapatkan uang sebanyak: Cp. ${income}  

📈 EXP yang didapat: ${expGained}  
🔥 Level Clan: ${clanForJelajah.level} (${clanForJelajah.exp}/${clanForJelajah.level * 1000})`);
   logActivity(clanIdForJelajah, `${global.db.data.users[sender]?.name || sender} melakukan jelajah.`);
  saveClan({ clans, members }); // Simpan perubahan ke Clan
  break;
}

    case 'up': {
      if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
      const clanIdForUpgrade = members[sender];
      const clanForUpgrade = clans[clanIdForUpgrade];
      const upgradeType = args[1];

      if (!['defense', 'attack'].includes(upgradeType)) throw 'Upgrade hanya bisa dilakukan pada defense atau attack.\n> contoh: .clan up defense';
      
      // Menentukan kebutuhan resources untuk upgrade
      let neededResources = {};
      if (upgradeType === 'defense') {
        neededResources = {
          wood: 5 + 10 * (clanForUpgrade.defenseLevel - 1),
          iron: 5 + 15 * (clanForUpgrade.defenseLevel - 1),
          diamond: 5 + 8 * (clanForUpgrade.defenseLevel - 1),
          rock: 5 + 25 * (clanForUpgrade.defenseLevel - 1),
          coal: 5 + 10 * (clanForUpgrade.defenseLevel - 1),
          string: 5 + 12 * (clanForUpgrade.defenseLevel - 1),
        };
      } else if (upgradeType === 'attack') {
        neededResources = {
          wood: 5 + 10 * (clanForUpgrade.attackLevel - 1),
          iron: 5 + 15 * (clanForUpgrade.attackLevel - 1),
          diamond: 5 + 8 * (clanForUpgrade.attackLevel - 1),
          rock: 5 + 25 * (clanForUpgrade.attackLevel - 1),
          coal: 5 + 10 * (clanForUpgrade.attackLevel - 1),
          string: 5 + 12 * (clanForUpgrade.attackLevel - 1),
        };
      }

      // Cek apakah clan punya cukup resource untuk upgrade
      let hasEnoughResources = true;
      let missingResources = '';
      for (let resource in neededResources) {
        const current = clanForUpgrade.resources[resource] || 0;
        const required = neededResources[resource];
        if (current < required) {
          hasEnoughResources = false;
          missingResources += `- ${resource}: ${current}/${required}\n`;
        }
      }

      if (!hasEnoughResources) {
        m.reply(`Kamu tidak memiliki cukup resource untuk upgrade ${upgradeType}.\n\nResource yang masih kurang:\n${missingResources.trim()}`);
        break;
      }

      // Kurangi resource sesuai dengan kebutuhan
      for (let resource in neededResources) {
        clanForUpgrade.resources[resource] -= neededResources[resource];
      }

      // Naikkan level sesuai tipe upgrade
      if (upgradeType === 'defense') {
        clanForUpgrade.defenseLevel += 1;
        clanForUpgrade.aegis = clanForUpgrade.defenseLevel * 50; // Naikkan Aegis
      } else if (upgradeType === 'attack') {
        clanForUpgrade.attackLevel += 1;
        clanForUpgrade.basics = 25 + (clanForUpgrade.attackLevel - 1) * 25; // Naikkan Basics
      }
      
      logActivity(clanIdForUpgrade, `${global.db.data.users[sender]?.name || sender} meng-upgrade ${upgradeType} clan.`);

      saveClan({ clans, members });
      m.reply(`Berhasil upgrade ${upgradeType}!\nLevel baru: ${clanForUpgrade[`${upgradeType}Level`]} ${upgradeType}`);
      break;
    }

    case 'war': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdWar = members[sender];
  const myClan = clans[clanIdWar];

  if (myClan.isInWar) throw 'Clan kamu sedang dalam war. Tunggu sampai war selesai sebelum melakukan war lagi.';

  const lastWarTime = myClan.lastWar || 0;
  const cooldownTime = 10 * 60 * 1000; // 10 menit
  const currentTime = Date.now();
  if (currentTime - lastWarTime < cooldownTime) {
    const remainingTime = Math.ceil((cooldownTime - (currentTime - lastWarTime)) / 60000);
    throw `Clan kamu harus menunggu ${remainingTime} menit lagi sebelum dapat melakukan war lagi.`;
  }

  if (myClan.aegis <= 0) throw 'Defense Clan kamu habis! Gunakan perintah .clan repair untuk memperbaikinya terlebih dahulu.';

  let opponentClan;
  const targetId = args[1]; // ID Clan yang ingin di-war
  if (targetId) {
    opponentClan = clans[targetId];
    if (!opponentClan) throw 'Clan dengan ID tersebut tidak ditemukan.';
    if (opponentClan.id === clanIdWar) throw 'Kamu tidak bisa war dengan clan sendiri.';
    if (opponentClan.isInWar || opponentClan.aegis <= 0) throw 'Clan lawan tidak bisa di-war (mungkin sedang dalam war atau defense habis).';
  } else {
    const availableClans = Object.values(clans).filter(clan =>
      clan.id !== clanIdWar && !clan.isInWar && (Date.now() - (clan.lastWar || 0)) >= cooldownTime && clan.aegis > 0
    );
    if (availableClans.length === 0) throw 'Tidak ada lawan yang tersedia untuk war.';
    opponentClan = availableClans[Math.floor(Math.random() * availableClans.length)];
  }

  myClan.isInWar = true;
  opponentClan.isInWar = true;

  const myCurrentAegis = myClan.aegis;
  const myCurrentBasics = myClan.basics;
  const opponentCurrentAegis = opponentClan.aegis;
  const opponentCurrentBasics = opponentClan.basics;

  m.reply(`*⚔️ CLAN WAR ⚔️*

*${myClan.name}* VS *${opponentClan.name}*

📊 Status Awal:

📝 Clan: ${myClan.name}
🛡 Defense (Aegis): ${myCurrentAegis}
⚔️ Attack (Basics): ${myCurrentBasics}

📝 Clan: ${opponentClan.name}
🛡 Defense (Aegis): ${opponentCurrentAegis}
⚔️ Attack (Basics): ${opponentCurrentBasics}

War berlangsung selama 5 menit...`);

  let myAegis = myCurrentAegis;
  let opponentAegis = opponentCurrentAegis;

  while (myAegis > 0 && opponentAegis > 0) {
    opponentAegis -= myCurrentBasics;
    if (opponentAegis <= 0) break;
    myAegis -= opponentCurrentBasics;
  }

  const winner = myAegis > 0 ? myClan : opponentClan;
  const loser = winner === myClan ? opponentClan : myClan;

  const winnerExp = Math.floor(Math.random() * 101) + 100;
  const winnerMoney = Math.floor(Math.random() * 201) + 500;
  const loserExpLoss = Math.floor(Math.random() * 41) + 10;
  const loserMoneyLoss = Math.floor(Math.random() * 101) + 100;

  setTimeout(() => {
    winner.exp += winnerExp;
    winner.bank += winnerMoney;
    loser.exp = Math.max(0, loser.exp - loserExpLoss);
    loser.bank = Math.max(0, loser.bank - loserMoneyLoss);

    myClan.aegis = Math.max(0, myAegis);
    opponentClan.aegis = Math.max(0, opponentAegis);

    myClan.lastWar = Date.now();
    opponentClan.lastWar = Date.now();

    myClan.isInWar = false;
    opponentClan.isInWar = false;

    saveClan({ clans, members });

    m.reply(`*⚔️ CLAN WAR ⚔️*

🏆 Winner: ${winner.name}
💥 Loser: ${loser.name}

📊 Status Akhir:

📝 ${winner.name}:
⚔️ Attack: ${myCurrentBasics}
🛡 Defense: ${winner.aegis}
🧪 EXP: +${winnerExp}
💰 Bank: +${winnerMoney}

📝 ${loser.name}:
⚔️ Attack: ${opponentCurrentBasics}
🛡 Defense: ${loser.aegis}
🧪 EXP: -${loserExpLoss}
💰 Bank: -${loserMoneyLoss}

🔥 Selamat untuk pemenang!`);
  }, 300000);

  break;
}

  case 'shop': {
  const action = args[1]?.toLowerCase();
  const item = args[2]?.toLowerCase();
  let amount = parseInt(args[3]);

  // Default amount to 1 if no quantity is provided (for buy and sell)
  if (!amount || amount <= 0) {
    amount = 1;
  }

  const prices = { wood: 5, iron: 10, diamond: 20, rock: 5, coal: 5, string: 5 };
  const sellPrices = { wood: 2.5, iron: 5, diamond: 10, rock: 2.5, coal: 2.5, string: 2.5 };
  const artifactPrices = { grimoire: 1000, scepter: 1750, crown: 1890, gemstone: 2150, cloak: 2100, spear: 2000 };

  const clanIdShop = members[sender];
  const myClan = clans[clanIdShop];

  if (!myClan) throw 'Kamu tidak berada dalam clan.';

  // Ensure artifacts are initialized
  if (!myClan.artifacts) {
    myClan.artifacts = {
      grimoire: 0,
      scepter: 0,
      crown: 0,
      gemstone: 0,
      cloak: 0,
      spear: 0,
    };
  }

  if (action === 'buy') {
    if (!item) throw 'Gunakan format: .clan shop buy <item> <jumlah>';

    if (!prices[item]) throw 'Item tidak ditemukan. Pilihan: wood, iron, diamond, rock, coal, string.';
    const price = prices[item] * amount;

    if (myClan.bank < price) throw `Bank tidak mencukupi. Dibutuhkan Cp. ${price}, tetapi hanya memiliki Cp. ${myClan.bank}.`;

    myClan.bank -= price;
    myClan.resources[item] = (myClan.resources[item] || 0) + amount;

    logActivity(clanIdShop, `${global.db.data.users[sender]?.name || sender} membeli ${amount} ${item} seharga Cp. ${price}`);
    saveClan({ clans, members });

    m.reply(`Berhasil membeli ${amount} ${item} seharga Cp. ${price}.`);
  } else if (action === 'sell') {
    if (!item) throw 'Gunakan format: .clan shop sell <item> <jumlah>';

    let sellPrice = 0;

    if (prices[item]) {
      // Selling resources
      if ((myClan.resources[item] || 0) < amount) throw `Kamu tidak memiliki cukup ${item} untuk dijual.`;
      sellPrice = Math.floor(sellPrices[item] * amount); // Sell price is half of the buy price
      myClan.resources[item] -= amount;

      logActivity(clanIdShop, `${global.db.data.users[sender]?.name || sender} menjual ${amount} ${item} seharga Cp. ${sellPrice}`);
    } else if (artifactPrices[item]) {
      // Check if user is owner or officer
      if (myClan.owner !== sender && (!myClan.officers || !myClan.officers.includes(sender))) {
        throw 'Hanya owner atau officer yang dapat menjual artefak.';
      }

      // Check if the clan has enough of the artifact
      if ((myClan.artifacts[item] || 0) < amount) {
        throw `Kamu hanya memiliki ${myClan.artifacts[item]} ${item}, tidak cukup untuk menjual ${amount}.`;
      }

      // Reduce the artifact count and calculate the sell price
      myClan.artifacts[item] -= amount;
      sellPrice = artifactPrices[item] * amount;
      myClan.bank += sellPrice;

      logActivity(clanIdShop, `${global.db.data.users[sender]?.name || sender} menjual ${amount} ${item} seharga Cp. ${sellPrice}`);
    } else {
      throw 'Item tidak ditemukan. Pilihan: wood, iron, diamond, rock, coal, string, atau artifact.';
    }

    // Add sell price to the clan bank
    saveClan({ clans, members });

    m.reply(`Berhasil menjual ${amount} ${item} dan mendapatkan Cp. ${sellPrice}.`);
  } else {
    // Default shop display if no action is provided
    m.reply(`🛒 \`C L A N   S H O P\` 🛒\n
💲 *Harga bahan (Beli & Jual):*
- 🌲 Wood: Beli Cp. 5, Jual Cp. 2.5  
- ⛏️ Iron: Beli Cp. 10, Jual Cp. 5  
- 💎 Diamond: Beli Cp. 20, Jual Cp. 10  
- 🪨 Rock: Beli Cp. 5, Jual Cp. 2.5  
- 🖤 Coal: Beli Cp. 5, Jual Cp. 2.5  
- 🧵 String: Beli Cp. 5, Jual Cp. 2.5  

🎁 *Harga Artefak (Hanya Bisa Dijual):*
- 📜 Grimoire: Cp. 1000
- ⚡ Scepter: Cp. 1750
- 👑 Crown: Cp. 1890
- 💎 Gemstone: Cp. 2150
- 🧥 Cloak: Cp. 2100
- ⚔️ Spear: Cp. 2000

📌 Gunakan: 
- .clan shop buy <item> <jumlah>
- .clan shop sell <item> <jumlah>`);
  }
  break;
}

    case 'join': {
  if (members[sender]) throw 'Kamu sudah berada di sebuah clan.';
  const clanIdJoin = args[1];
  const clan = clans[clanIdJoin];
  if (!clan) throw 'Clan tidak ditemukan. Isi ID Clan\n\nUntuk cari ID clan\nketik: .clan list\nUntuk join clan\n> contoh: .clan join 0phtuh';
  if (clan.settings.approval) throw 'Clan ini private. Kamu tidak dapat bergabung.';
  clan.members.push(sender);
  members[sender] = clanIdJoin;
  logActivity(clanIdJoin, `${global.db.data.users[sender]?.name || sender} bergabung ke clan.`);
  saveClan({ clans, members });
  m.reply(`Kamu berhasil bergabung dengan clan "${clan.name}".`);
  break;
}

    case 'out': {
  const clanIdOut = members[sender];
  if (!clanIdOut) throw 'Kamu tidak berada dalam clan.';
  const clan = clans[clanIdOut];

  // Hapus member dari clan
  clan.members = clan.members.filter((m) => m !== sender);
  delete members[sender];

  // Jika pengguna adalah officer, hapus dari daftar officer
  if (clan.officers?.includes(sender)) {
    clan.officers = clan.officers.filter((officer) => officer !== sender);
  }

  if (clan.owner === sender) {
    if (clan.members.length > 0) {
      // Tetapkan anggota tertua sebagai owner baru
      const newOwner = clan.members[0];
      clan.owner = newOwner;
      m.reply(`Kamu telah keluar dari clan. Kepemilikan clan "${clan.name}" sekarang diberikan kepada @${newOwner.split('@')[0]}.`);
    } else {
      // Hapus clan jika tidak ada anggota
      delete clans[clanIdOut];
      m.reply(`Kamu telah keluar dari clan, dan clan "${clan.name}" telah dihapus karena tidak ada anggota tersisa.`);
    }
  } else {
    m.reply(`Kamu telah keluar dari clan "${clan.name}".`);
  }

   logActivity(clanIdOut, `${global.db.data.users[sender]?.name || sender} keluar dari clan.`);
  saveClan({ clans, members });
  break;
}
  
    case 'private': { // Fitur mengubah pengaturan private
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForPrivate = members[sender];
  const clanForPrivate = clans[clanIdForPrivate];

  if (clanForPrivate.owner !== sender) throw 'Hanya owner clan yang dapat mengubah pengaturan privasi.';

  const toggle = args[1]?.toLowerCase();
  if (!['on', 'off'].includes(toggle)) throw 'Gunakan: .clan private <on/off>';

  clanForPrivate.settings.approval = toggle === 'on';
  saveClan({ clans, members });

  m.reply(`Privasi clan berhasil diubah menjadi ${toggle === 'on' ? 'ON (Private)' : 'OFF (Public)'}`);
  break;
   }
   
   case 'list': {
  if (Object.keys(clans).length === 0) {
    return m.reply('Belum ada clan yang tersedia.');
  }

  // Ambil semua clan dalam array
  const allClans = Object.values(clans);

  // Acak array clans
  const shuffledClans = allClans.sort(() => Math.random() - 0.5);

  // Ambil maksimal 5 clan
  const displayedClans = shuffledClans.slice(0, 5);

  // Format output
  const clanList = displayedClans
    .map(
      (clan, index) =>
        `${index + 1}. 📝 Clan Name: *${clan.name}*\n🆔 ID: ${clan.id}\n👤 Members: ${clan.members.length} / 15\n🔒 Private: ${clan.settings.approval ? 'ON' : 'OFF'}`
    )
    .join('\n\n');

  m.reply(`
*List Clan (Total: ${Object.keys(clans).length})*
${clanList}
  `.trim());
  break;
}
   
   case 'repair': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForRepair = members[sender];
  const clanForRepair = clans[clanIdForRepair];

  // Pastikan properti clan tersedia
  if (!clanForRepair.resources) clanForRepair.resources = {};
  if (clanForRepair.aegis == null) clanForRepair.aegis = 0; // Inisialisasi Aegis
  if (clanForRepair.defenseLevel == null) clanForRepair.defenseLevel = 1; // Inisialisasi Defense Level

  // Maksimal Aegis berdasarkan level defense
  const maxAegis = clanForRepair.defenseLevel * 50;

  // Nilai Aegis saat ini
  const currentAegis = clanForRepair.aegis;

  // Jika Aegis sudah maksimal
  if (currentAegis >= maxAegis) {
    return m.reply(`Defense clan sudah maksimal:\n- Aegis: ${currentAegis}/${maxAegis}`);
  }

  // Cek resources untuk repair
  const repairCost = {
    wood: 10 * clanForRepair.defenseLevel,
    iron: 5 * clanForRepair.defenseLevel,
    diamond: 2 * clanForRepair.defenseLevel,
    rock: 8 * clanForRepair.defenseLevel,
    coal: 6 * clanForRepair.defenseLevel,
    string: 4 * clanForRepair.defenseLevel,
  };

  // Pastikan resource mencukupi
  let hasEnoughResources = true;
  let missingResources = '';
  for (let resource in repairCost) {
    const available = clanForRepair.resources[resource] || 0;
    const required = repairCost[resource];
    if (available < required) {
      hasEnoughResources = false;
      missingResources += `- ${resource}: ${available}/${required}\n`;
    }
  }

  if (!hasEnoughResources) {
    return m.reply(`Resource tidak mencukupi untuk repair:\n${missingResources}`);
  }

  // Kurangi resource dan perbaiki Aegis
  for (let resource in repairCost) {
    clanForRepair.resources[resource] -= repairCost[resource];
  }
  clanForRepair.aegis = maxAegis; // Perbaiki langsung ke maksimal

  saveClan({ clans, members });
  m.reply(`Defense clan berhasil diperbaiki hingga maksimal:\n- Defense: ${clanForRepair.aegis}/${maxAegis}`);
  break;
}

    case 'kick': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForKick = members[sender];
  const clanForKick = clans[clanIdForKick];

  // Pengecekan apakah sender adalah owner atau officer
  const isOwner = clanForKick.owner === sender;
  const isOfficer = (clanForKick.officers || []).includes(sender);
  if (!isOwner && !isOfficer) {
    throw 'Hanya owner atau officer clan yang dapat mengeluarkan anggota.';
  }

  const memberToKick = args[1]?.replace('@', '').trim(); // Hapus "@" jika ada
  if (!memberToKick) throw 'Gunakan: .clan kick @tag atau .clan kick <nomor ID>';

  // Cari member berdasarkan ID atau @tag
  const targetMember = clanForKick.members.find((m) => m.includes(memberToKick));
  if (!targetMember) throw 'Member tidak ditemukan dalam clan.';

  // Validasi: officer tidak dapat mengeluarkan owner atau sesama officer
  if (targetMember === clanForKick.owner) {
    throw 'Tidak dapat mengeluarkan owner clan.';
  }
  if (isOfficer && (clanForKick.officers || []).includes(targetMember)) {
    throw 'Officer tidak dapat mengeluarkan sesama officer.';
  }

  // Hapus dari daftar officer jika target adalah officer
  clanForKick.officers = clanForKick.officers || [];
  if (clanForKick.officers.includes(targetMember)) {
    clanForKick.officers = clanForKick.officers.filter((id) => id !== targetMember);
  }

  // Mengeluarkan anggota dari clan
  clanForKick.members = clanForKick.members.filter((m) => m !== targetMember);
  delete members[targetMember]; // Hapus data member dari global data

  logActivity(clanIdForKick, `${global.db.data.users[sender]?.name || sender} mengeluarkan @${targetMember.split('@')[0]}`);

  saveClan({ clans, members });
  m.reply(`Berhasil mengeluarkan anggota: @${targetMember.split('@')[0]} dari clan *${clanForKick.name}*.`, null, {
    mentions: [targetMember],
  });
  break;
}
   
   case 'setprofile': {
    if (!members[sender]) throw 'Kamu belum bergabung dengan clan.\nCari atau buat clan terlebih dahulu.';
    
    function formatBytes(bytes) {
        if (bytes === 0) return "0 B";
        const sizes = ["B", "KB", "MB", "GB", "TB"];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
    }

    async function catbox(content) {
        const { ext, mime } = await fileTypeFromBuffer(content) || {};
        if (!ext || !mime || !mime.startsWith('image/')) throw 'Hanya gambar yang diperbolehkan sebagai profil clan.';
        
        const blob = new Blob([content], { type: mime });
        const formData = new FormData();
        const randomBytes = crypto.randomBytes(5).toString("hex");
        formData.append("reqtype", "fileupload");
        formData.append("fileToUpload", blob, `${randomBytes}.${ext}`);
        
        const response = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: formData,
        });

        if (!response.ok) throw 'Gagal mengunggah file ke Catbox.';
        const url = await response.text();
        return url;
    }

    // Ambil clan terkait
    const clanId = members[sender];
    const clan = clans[clanId];

    if (clan.owner !== sender) throw 'Hanya owner clan yang dapat mengatur profil.';

    // Periksa apakah pengguna mengirim gambar langsung atau mereply gambar
    let media;
    let caption = m.message?.imageMessage?.caption || '';
    if (m.type === 'imageMessage' && m.message.imageMessage) {
        // Jika mengirim gambar langsung dengan caption
        media = await m.download();
    } else if (m.quoted && (m.quoted.msg || m.quoted).mimetype.startsWith('image/')) {
        // Jika mereply gambar
        media = await m.quoted.download();
        caption = m.message?.extendedTextMessage?.text || ''; // Ambil pesan dari reply
    } else {
        throw 'Reply gambar dengan caption "clan setprofile" untuk mengatur gambar profil clan.';
    }

    if (!media) throw 'Gagal mengunduh media. Coba lagi.';
    
    // Ubah gambar menjadi URL
    let profileUrl = await catbox(media);
    if (!profileUrl) throw 'Gagal mengunggah gambar. Coba lagi.';
    
    // Simpan URL sebagai profil clan
    clan.profile = profileUrl;
    clan.profileMessage = caption || 'Tidak ada pesan'; // Tambahkan pesan opsional
    saveClan({ clans, members });

    m.reply(`✅ Profil clan berhasil diperbarui!\n\n*Nama Clan*: ${clan.name}`);
    break;
}

    case 'delprofile': {
    if (!members[sender]) throw 'Kamu belum bergabung dengan clan.\nCari atau buat clan terlebih dahulu.';

    // Ambil clan terkait
    const clanId = members[sender];
    const clan = clans[clanId];

    if (clan.owner !== sender) throw 'Hanya owner clan yang dapat menghapus profil clan.';

    if (!clan.profile) throw 'Clan ini tidak memiliki profil yang diatur.';

    // Hapus profil clan
    delete clan.profile;
    delete clan.profileMessage;
    saveClan({ clans, members });

    m.reply(`✅ Profil clan berhasil dihapus!\n\n*Nama Clan*: ${clan.name}`);
    break;
}

    case 'leaderboard': {
    // Mengambil daftar clan dan menghitung skor total (level + exp)
    const sortedClans = Object.values(clans)
        .map(clan => ({
            ...clan,
            totalScore: clan.level + clan.exp, // Menggabungkan level dan exp
        }))
        .sort((a, b) => b.totalScore - a.totalScore); // Urutkan berdasarkan totalScore

    // Mengambil 5 clan teratas
    const leaderboard = sortedClans.slice(0, 5);

    // Menyiapkan pesan leaderboard
    let leaderboardMessage = '*Clan Leaderboard*\n\n';
leaderboard.forEach((clan, index) => {
    leaderboardMessage += `${index + 1}. 📝 Clan: ${clan.name}\n📊 Level: ${clan.level}\n🧪 Exp: ${clan.exp}\n💯 Total Score: ${clan.totalScore}\n💰 Bank: Cp. ${clan.bank}\n\n`;
});

    // Mengirimkan pesan leaderboard
    m.reply(leaderboardMessage);
    break;
}
    
    case 'member': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.\nCari atau buat clan terlebih dahulu.';
  
  const clanIdForMembers = members[sender];
  const clanForMembers = clans[clanIdForMembers];
  
  if (clanForMembers.members.length === 0) throw 'Clan ini belum memiliki anggota selain kamu.';

  // Dapatkan daftar nama member dan mention user
  const memberMentions = clanForMembers.members.map((m) => {
    const user = global.db.data.users[m];
    const userName = user?.name || 'Tidak diketahui';
    return `@${m.split('@')[0]} - ${userName}`;
  }).join('\n');
  
  // Kirim daftar member dengan mention
  m.reply(`*Anggota Clan:*\n\nTotal Anggota: ${clanForMembers.members.length} | 15\n\n${memberMentions}`, null, {
    mentions: clanForMembers.members,
  });
  break;
}
 
 case 'dungeon': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForDungeon = members[sender];
  const clanForDungeon = clans[clanIdForDungeon];

  if (clanForDungeon.attackLevel < 3 || clanForDungeon.defenseLevel < 3) {
    throw `⚔️ Clan kamu harus memiliki level *Attack* dan *Defense* minimal 3 untuk menjelajahi dungeon. 
Naikkan level Defense dan Attack terlebih dahulu!`;
  }

  const lastCompletedTime = clanForDungeon.dungeonCooldown?.[sender]?.lastCompleted || 0;
  const dungeonCooldown15min = 15 * 60 * 1000; // 15 menit cooldown
  const currentTime = Date.now();

  if (currentTime - lastCompletedTime < dungeonCooldown15min) {
    const remainingTime = Math.ceil((dungeonCooldown15min - (currentTime - lastCompletedTime)) / 1000);

    const hours = Math.floor(remainingTime / 3600);
    const minutes = Math.floor((remainingTime % 3600) / 60);
    const seconds = remainingTime % 60;

    throw `⏳ Kamu masih kelelahan tunggu dalam *${hours} jam ${minutes} menit ${seconds} detik*.`;
  }

  const resources = {
    iron: '⛏️',
    diamond: '💎',
    rock: '🪨',
    coal: '⛓️',
    string: '🧵'
  };
  const levelMultiplier = 1 + (clanForDungeon.level * 0.5);
  let foundResources = {};

  Object.keys(resources).forEach(resource => {
    const baseAmount = Math.floor(Math.random() * 15) + 5;
    foundResources[resource] = Math.ceil(baseAmount * levelMultiplier);
  });

  const minIncome = 50, maxIncome = 100;
  const income = Math.ceil((Math.random() * (maxIncome - minIncome + 1) + minIncome) * levelMultiplier);

  const artifacts = [
    { name: 'grimoire', emoji: '📜' },
    { name: 'scepter', emoji: '⚡' },
    { name: 'crown', emoji: '👑' },
    { name: 'gemstone', emoji: '💎' },
    { name: 'cloak', emoji: '🧥' },
    { name: 'spear', emoji: '⚔️' }
  ];
  const artifactChance = Math.random() * 100;
  const foundArtifact = artifactChance <= 1
    ? artifacts[Math.floor(Math.random() * artifacts.length)]
    : null;

  const baseExp = Math.floor(Math.random() * 20) + 10;
  const expGained = Math.ceil(baseExp * levelMultiplier);

  let response = `\`D U N G E O N   R E S U L T S\`\n\n`;

  Object.keys(resources).forEach(resource => {
    response += `- ${resources[resource]} ${resource.charAt(0).toUpperCase() + resource.slice(1)}: ${foundResources[resource]}\n`;
  });

  response += `
💰 Bank: Cp. ${income}
📈 EXP: ${expGained}
🔥 Clan Level: ${clanForDungeon.level} (${clanForDungeon.exp}/${clanForDungeon.level * 1000})`;

  if (foundArtifact) {
    response += `\n\n🎉 *You found a rare artifact!*: ${foundArtifact.emoji} ${foundArtifact.name.charAt(0).toUpperCase() + foundArtifact.name.slice(1)}\n`;
    response += `📦 Total ${foundArtifact.name.charAt(0).toUpperCase() + foundArtifact.name.slice(1)}: ${(clanForDungeon.artifacts[foundArtifact.name] || 0) + 1}`;
  }

  conn.reply(m.chat, response, m);

  // Update clan resources and income
  Object.keys(resources).forEach(resource => {
    clanForDungeon.resources[resource] += foundResources[resource];
  });
  clanForDungeon.bank += income;

  // Update artifacts
  clanForDungeon.artifacts = clanForDungeon.artifacts || { 
    grimoire: 0, 
    scepter: 0, 
    crown: 0, 
    gemstone: 0, 
    cloak: 0, 
    spear: 0 
  };
  
  if (foundArtifact) {
    const artifactKey = foundArtifact.name; // Key sesuai nama artefak
    if (clanForDungeon.artifacts[artifactKey] !== undefined) {
      clanForDungeon.artifacts[artifactKey]++;
    }
  }

  // Update experience and level
  clanForDungeon.exp += expGained;
  const requiredExp = clanForDungeon.level * 1000;
  if (clanForDungeon.exp >= requiredExp) {
    clanForDungeon.exp -= requiredExp;
    clanForDungeon.level++;
  }

  // Update dungeon cooldown
  if (!clanForDungeon.dungeonCooldown) clanForDungeon.dungeonCooldown = {};
  clanForDungeon.dungeonCooldown[sender] = {
    lastCompleted: currentTime
  };

  logActivity(clanIdForDungeon, `${global.db.data.users[sender]?.name || sender} menyelesaikan dungeon.`);
  saveClan({ clans, members });

  break;
}

  case 'fix': {
  // Cek apakah user memiliki izin khusus (opsional)
  if (!isOwner) throw 'Perintah ini hanya dapat digunakan oleh pemilik bot.';

  // Reset semua clan isInWar ke false
  for (const clanId in clans) {
    if (clans[clanId].isInWar) {
      clans[clanId].isInWar = false;
    }
  }

  // Simpan data clan setelah reset
  saveClan({ clans, members });

  // Konfirmasi kepada user
  m.reply('*✅ Semua status war clan telah direset ke false.*');
  break;
}

  case 'owner': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForTransfer = members[sender];
  const clanForTransfer = clans[clanIdForTransfer];

  if (clanForTransfer.owner !== sender) throw 'Hanya owner clan yang dapat mentransfer kepemilikan.';

  const targetMemberId = args[1]?.replace('@', '').trim(); // Hapus "@" jika ada
  if (!targetMemberId) throw 'Gunakan: .clan owner @tag atau .clan owner <nomor ID>';

  // Cari target berdasarkan ID atau nomor
  const targetOwner = clanForTransfer.members.find((m) => m.includes(targetMemberId));
  if (!targetOwner) throw 'Pengguna tersebut tidak ditemukan dalam clan.';

  if (targetOwner === sender) throw 'Kamu sudah menjadi owner clan.';

  // Transfer owner ke target
  clanForTransfer.owner = targetOwner;

  saveClan({ clans, members });
  m.reply(`Kepemilikan clan "${clanForTransfer.name}" berhasil ditransfer ke @${targetOwner.split('@')[0]}`, null, { mentions: [targetOwner] });
  break;
}

  case 'transfer': {
  const targetClanId = args[1];
  const item = args[2]?.toLowerCase();
  const amount = parseInt(args[3]);

  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdTf = members[sender];
  const clan = clans[clanIdTf];

  // Pengecekan owner dan officer
  const isOwner = clan.owner === sender; // Pengecekan apakah user adalah owner
  const isOfficer = (clan.officers || []).includes(sender); // Pengecekan apakah user adalah officer

  // Jika bukan owner atau officer, tolak akses
  if (!isOwner && !isOfficer) {
    throw 'Hanya owner atau officer clan yang bisa melakukan transfer.';
  }

  // Daftar item dengan emoji
  const validItemsWithEmoji = {
    wood: '🪵 Wood',
    iron: '🪨 Iron',
    diamond: '💎 Diamond',
    rock: '🪨 Rock',
    coal: '⚫ Coal',
    string: '🧵 String',
    bank: '🏦 Bank',
  };

  // Validasi input
  if (!targetClanId || !item || !amount || amount <= 0 || !Object.keys(validItemsWithEmoji).includes(item)) {
    throw `\`C L A N  T R A N S F E R\`
    
${Object.values(validItemsWithEmoji).join('\n')}
    
Gunakan format: 
.clan transfer <id clan> <item> <jumlah>`;
  }

  const targetClan = clans[targetClanId];
  if (!targetClan) throw 'Clan tujuan tidak ditemukan.';

  // Cek apakah memiliki cukup item
  if (item === 'bank') {
    if (clan.bank < amount) throw 'Saldo bank tidak mencukupi untuk transfer.';
    clan.bank -= amount;
    targetClan.bank = (targetClan.bank || 0) + amount;
  } else {
    clan.resources = clan.resources || {};
    targetClan.resources = targetClan.resources || {};

    if (clan.resources[item] < amount) throw `Kamu tidak memiliki cukup ${validItemsWithEmoji[item]} untuk ditransfer.`;
    clan.resources[item] -= amount;
    targetClan.resources[item] = (targetClan.resources[item] || 0) + amount;
  }

  // Log aktivitas
  logActivity(clanIdTf, `${global.db.data.users[sender]?.name || sender} mentransfer ${amount} ${validItemsWithEmoji[item]} ke clan *${targetClan.name}*`);
  saveClan({ clans, members }); // Simpan perubahan

  m.reply(`Berhasil mentransfer ${amount} ${validItemsWithEmoji[item]} ke clan *${targetClan.name}*.`);
  break;
}

   case 'activity': {
  if (!members[sender]) return m.reply('Kamu belum bergabung dengan clan.');
  const activityClanId = members[sender];
  const activityLog = clans[activityClanId].activityLog || [];
  if (activityLog.length === 0) return m.reply('Belum ada aktivitas dalam clan ini.');
  
  const latestLogs = activityLog.slice(-10).reverse(); // Reverse the order of the last 10 logs
  const formattedLog = latestLogs.map(entry => {
    // Adjust timestamp to WIB (UTC+7)
    const time = new Date(entry.timestamp).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    return `- [${time}] ${entry.message}`;
  }).join('\n');
  
  m.reply(`*Log Aktivitas Clan (10 Terakhir):*\n${formattedLog}`);
  break;
}
  
  case 'promote': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdPromote = members[sender];
  const clan = clans[clanIdPromote];

  if (!clan) throw 'Clan tidak ditemukan.';
  if (clan.owner !== sender) throw 'Hanya owner clan yang bisa menjadikan seseorang sebagai officer.';

  const targetMemberId = args[1]?.replace('@', '').trim(); // Hapus "@" jika ada
  if (!targetMemberId) throw 'Gunakan: .clan promote @tag atau .clan promote <nomor ID>';

  // Cari target berdasarkan ID atau nomor
  const targetUser = clan.members.find((m) => m.includes(targetMemberId));
  if (!targetUser) throw 'Pengguna tersebut tidak ditemukan dalam clan.';

  // Pastikan pengguna bukan owner
  if (targetUser === sender) throw 'Kamu tidak dapat mempromosikan diri sendiri.';

  // Inisialisasi daftar officer jika belum ada
  clan.officers = clan.officers || [];

  // Cek batas maksimal officer
  if (clan.officers.length >= 3) throw 'Officer dalam clan ini sudah mencapai batas maksimal (3).';

  // Pastikan pengguna belum menjadi officer
  if (clan.officers.includes(targetUser)) throw 'Pengguna tersebut sudah menjadi officer.';

  // Tambahkan pengguna ke daftar officer
  clan.officers.push(targetUser);
  logActivity(clanIdPromote, `${global.db.data.users[sender]?.name || sender} promote @${targetUser.split('@')[0]}`);
  saveClan({ clans, members });

  m.reply(`@${targetUser.split('@')[0]} telah diangkat menjadi officer di clan *${clan.name}*.`, null, {
    mentions: [targetUser],
  });
  break;
}

  case 'nebang': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdForNebang = members[sender];
  const clanForNebang = clans[clanIdForNebang];

  // Cek apakah pengguna sedang dalam cooldown
  const lastNebangTime = clanForNebang.memberCooldownsV2?.[sender] || 0;
  const cooldownTime = 15 * 60 * 1000; // 15 menit dalam milidetik
  const currentTime = Date.now();

  if (currentTime - lastNebangTime < cooldownTime) {
    const remainingTime = Math.ceil((cooldownTime - (currentTime - lastNebangTime)) / 60000);
    throw `Kamu harus menunggu ${remainingTime} menit lagi sebelum dapat melakukan nebang lagi.`;
  }

  // Update waktu terakhir nebang untuk member
  clanForNebang.memberCooldownsV2 = clanForNebang.memberCooldownsV2 || {};
  clanForNebang.memberCooldownsV2[sender] = currentTime;

  // Menentukan hasil sesuai level clan
  const levelMultiplier = 1 + (clanForNebang.level - 1) * 0.5; // Pengali berdasarkan level clan (50% per level)

  const wood = Math.floor((10 + Math.random() * 10) * levelMultiplier); // 10-20 * multiplier
  const strings = Math.floor((10 + Math.random() * 10) * levelMultiplier); // 10-20 * multiplier
  const expGained = Math.floor((10 + Math.random() * 20) * levelMultiplier); // 10-30 * multiplier
  const bankIncome = Math.floor((20 + Math.random() * 30) * levelMultiplier); // 20-50 * multiplier

  // Tambahkan hasil ke resources clan
  clanForNebang.resources.wood = (clanForNebang.resources.wood || 0) + wood;
  clanForNebang.resources.string = (clanForNebang.resources.string || 0) + strings;
  clanForNebang.bank += bankIncome;
  clanForNebang.exp += expGained;

  // Hitung EXP untuk naik level clan
  const requiredExp = clanForNebang.level * 1000;

  // Periksa apakah clan naik level
  if (clanForNebang.exp >= requiredExp) {
    clanForNebang.exp -= requiredExp; // Sisa EXP diteruskan
    clanForNebang.level++; // Naik level
  }

  // Notifikasi hasil ke pemain
  m.reply(`🪵 *Hasil Nebang*
  
  - 🌲 Wood: ${wood}  
  - 🧵 String: ${strings}  
  - 💰 Bank Clan: ${bankIncome}  
  - ⭐ EXP: ${expGained}  

🔥 *Level Clan*: ${clanForNebang.level} (${clanForNebang.exp}/${requiredExp})`);

  // Log aktivitas dan simpan data clan
  logActivity(clanIdForNebang, `${global.db.data.users[sender]?.name || sender} melakukan nebang.`);
  saveClan({ clans, members });

  break;
}
  
  case 'demote': {
  if (!members[sender]) throw 'Kamu belum bergabung dengan clan.';
  const clanIdDemote = members[sender];
  const clan = clans[clanIdDemote];

  if (!clan) throw 'Clan tidak ditemukan.';
  if (clan.owner !== sender) throw 'Hanya owner clan yang bisa menurunkan officer menjadi anggota.';

  const targetMemberId = args[1]?.replace('@', '').trim(); // Hapus "@" jika ada
  if (!targetMemberId) throw 'Gunakan: .clan demote @tag atau .clan demote <nomor ID>';

  // Cari target berdasarkan ID atau nomor
  const targetUser = clan.officers.find((m) => m.includes(targetMemberId));
  if (!targetUser) throw 'Pengguna tersebut tidak ditemukan atau bukan seorang officer.';

  // Hapus pengguna dari daftar officer
  clan.officers = clan.officers.filter((id) => id !== targetUser);
  logActivity(clanIdDemote, `${global.db.data.users[sender]?.name || sender} demote @${targetUser.split('@')[0]}`);
  saveClan({ clans, members });

  m.reply(`@${targetUser.split('@')[0]} telah diturunkan jabatannya menjadi anggota biasa di clan *${clan.name}*.`, null, {
    mentions: [targetUser],
  });
  break;
}

    default:
      m.reply('Perintah Tidak di temukan.\nketik: .clan');
      break;
  }
 
};

handler.help = ['clan create', 'clan profile', 'clan jelajah', 'clan up', 'clan war', 'clan join', 'clan shop', 'clan repair', 'clan list', 'clan private', 'clan out', 'clan kick', 'clan setprofile', 'clan leaderboard', 'clan promote', 'clan demote', 'clan member', 'clan owner', 'clan delprofile', 'clan transfer', 'clan activity', 'clan dungeon', 'clan nebang'];
handler.tags = ['rpg'];
handler.command = /^clan$/i;
handler.limit = 1;
handler.register = true;
handler.group = true;

export default handler;