let handler = async (m, { conn, command, usedPrefix, text, args }) => {
     let user = text.split('|')[0];
     let moneyValue = text.split('|')[1];
    if(!text.includes("|")) return m.reply(`example:\n${usedPrefix + command} @${m.sender.split`@`[0]}|700`);
    if (m.mentionedJid.length > 0 || m?.quoted) {
        user = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
    } else {
        user = `${user.replace(/[^0-9]/g, "")}@s.whatsapp.net`;
    }
    
    if (isNaN(moneyValue)) throw 'Jumlah money harus angka!'

    // Converting moneyValue to a number
    moneyValue = parseInt(moneyValue)

    let users = global.db.data.users

    // Checking if the user is in the database, if not, initialize their money to 0
    if (!users[user]) users[user] = { money: 0 }

    // Determining whether to add or remove money based on the command
    if (command === 'addmoney') {
        // Adding the specified money to the user's account
        users[user].money += moneyValue
        conn.reply(m.chat, `Berhasil menambahkan ${moneyValue} money untuk @${user.split('@')[0]}!`, m)
    } else if (command === 'removemoney') {
        if (moneyValue > users[user].money) {
            // Set the user's money to 0 if the specified money is greater than the user's current money
            users[user].money = 0
            conn.reply(m.chat, `Berhasil mengurangi money untuk @${user.split('@')[0]}. Money kini menjadi 0!`, m)
        } else {
            // Removing the specified money from the user's account
            users[user].money -= moneyValue
            conn.reply(m.chat, `Berhasil mengurangi ${moneyValue} money untuk @${user.split('@')[0]}!`, m)
        }
    }
}

handler.help = ['addmoney', 'remmoney']
handler.tags = ['owner']
handler.command = /^(add|rem)money$/i
handler.mods = true

export default handler