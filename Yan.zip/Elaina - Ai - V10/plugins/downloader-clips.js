import fetch from "node-fetch"

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Teksnya mana yaa?");

  try {
    let apiUrl = `https://apizell.web.id/search/clipsvideo?q=${text}`;
    let response = await fetch(apiUrl);
    let data = await response.json();

    if (!data) {
      return m.reply("gaada videonya kaa");
    }

    let clip = data.results[0]; // hasil paling atas

    let caption = `
🎬 *Movie:* ${clip.movie}
⏳️ *Time:* ${clip.time}
💬 *Quote:* ${clip.quote}
📥 *Download Success!*`;

    conn.sendMessage( m.chat, { video: { url: clip.video }, mimetype: "video/mp4", caption: caption}, { quoted: m }
    );
  } catch (e) {
    console.error(e);
    m.reply("yahh lagi error kaa");
  }
};

handler.help = ["clips"]
handler.command = /^clips$/i
handler.tags = ["downloader"]

export default handler