import fetch from 'node-fetch';

let handler = async (m, { conn, usedPrefix, text, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply(`❌ Perintah ini hanya bisa digunakan di grup!`);

    // Pastikan database tersedia
    global.db.data.chats = global.db.data.chats || {};
    const chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    chat.absen = chat.absen || { participants: [], text: '', startTime: 0 };

    const now = Date.now();
    const EXPIRY = 24 * 60 * 60 * 1000; // 24 jam dalam milidetik

    // --- MULAI ABSEN ---
    if (/^(start|mulai)absen$/i.test(command)) {
        if (!(isAdmin || isOwner)) {
            return m.reply(`❌ *Hanya admin atau pemilik grup yang dapat memulai absen!*`);
        }

        if (chat.absen.startTime && now - chat.absen.startTime < EXPIRY) {
            return m.reply(`⚠️ *Masih ada absen yang berlangsung!* Gunakan *${usedPrefix}hapusabsen* untuk menghapus absen lama.`);
        }

        let groupMetadata = await conn.groupMetadata(m.chat).catch(() => null);
        if (!groupMetadata) return m.reply(`❌ *Gagal mengambil data grup!* Pastikan bot memiliki izin membaca grup.`);

        let participants = groupMetadata.participants.map(p => p.id);
        let absenText = text?.trim() || '📢 Absen dimulai!';

        // Simpan data absen ke database
        chat.absen = { participants: [], text: absenText, startTime: now };

        let mentionText = `📢 *${absenText}*\n\nKirim *${usedPrefix}absen* untuk mengabsen!\n\n` +
            participants.map(jid => `• @${jid.split('@')[0]}`).join('\n');

        return conn.sendMessage(m.chat, { text: mentionText, mentions: participants }, { quoted: m });
    }

    // --- HAPUS ABSEN ---
    if (/^(delete|hapus)absen$/i.test(command)) {
        if (!(isAdmin || isOwner)) {
            return m.reply(`❌ *Hanya admin atau pemilik grup yang dapat menghapus absen!*`);
        }

        if (!chat.absen.startTime) {
            return m.reply(`⚠️ *Tidak ada absen berlangsung di grup ini!* Gunakan *${usedPrefix}mulaiabsen* untuk memulai absen.`);
        }

        chat.absen = { participants: [], text: '', startTime: 0 };
        return m.reply(`✅ *Absen telah dihapus!*`);
    }

    // --- CEK ABSEN ---
    if (/^cekabsen$/i.test(command)) {
        if (!chat.absen.startTime) {
            return m.reply(`⚠️ *Tidak ada absen berlangsung di grup ini!* Gunakan *${usedPrefix}mulaiabsen* untuk memulai absen.`);
        }

        let d = new Date();
        let date = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' });

        let daftarAbsen = chat.absen.participants.map((p, i) => 
            `• ${i + 1}. @${p.id.split('@')[0]}${p.note ? `\n   📝 *Keterangan:* ${p.note}` : ''}`
        ).join('\n') || '_Belum ada yang absen._';

        let caption = `
📅 *Tanggal:* ${date}
📢 *${chat.absen.text}*

✅ *Absen saat ini sedang berlangsung!*
👥 *Daftar yang sudah absen:*\n${daftarAbsen}
`.trim();

        return conn.sendMessage(m.chat, { text: caption, mentions: chat.absen.participants.map(p => p.id) }, { quoted: m });
    }

    // --- ABSEN ---
    if (/^absen$/i.test(command)) {
        if (!chat.absen.startTime) {
            return m.reply(`⚠️ *Tidak ada absen berlangsung di grup ini!* Gunakan *${usedPrefix}mulaiabsen* untuk memulai absen.`);
        }

        if (chat.absen.participants.some(p => p.id === m.sender)) {
            return m.reply(`⚠️ *Anda sudah mengabsen sebelumnya!*`);
        }

        let note = text?.trim() || '';
        chat.absen.participants.push({ id: m.sender, note });

        let responseText = `✅ *Berhasil absen!*`;
        if (note) {
            responseText += `\n📝 *Keterangan:* ${note}`;
        }

        return m.reply(responseText);
    }

    return m.reply(`❌ Perintah tidak dikenal. Gunakan salah satu:\n\n${usedPrefix}mulaiabsen [teks]\n${usedPrefix}hapusabsen\n${usedPrefix}cekabsen\n${usedPrefix}absen [teks]`);
};

handler.help = ['mulaiabsen [teks]', 'hapusabsen', 'cekabsen', 'absen [teks]'];
handler.tags = ['absen'];

handler.command = /^(start|mulaiabsen|hapusabsen|cekabsen|absen)$/i;
handler.group = true;

export default handler;