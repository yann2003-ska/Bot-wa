let handler = async (m, { conn, command, groupMetadata }) => {
    // Pastikan data chat ada
    if (!global.db.data.chats[m.chat]) {
        return m.reply("🚫 Data chat group tidak ditemukan!");
    }

    let chat = global.db.data.chats[m.chat];
    let user = chat.member;
    let participants = groupMetadata.participants; // Ambil peserta dari groupMetadata
    let member = participants.map(participant => participant.id); // Ambil ID peserta

    // Cek apakah perintah adalah reset
    if (/resetlisttotalpesan/i.test(command)) {
        // Reset total chat dengan mengosongkan data member
        chat.member = {}; // Reset member ke kosong
        await m.reply("✅ Berhasil mereset total chat group! Semua member sekarang mulai dari 0 pesan.");
        return; // Menghentikan eksekusi lebih lanjut
    }

    // Jika tidak ada member
    if (member.length === 0) {
        return m.reply("🚫 Tidak ada member dalam group ini!");
    }

    let mentions = [];
    let totalPesan = 0; // Variabel untuk menghitung total pesan
    let caption = '📊 Ini adalah total pesan group:\n\n';

    let messageCounts = []; // Array untuk menyimpan jumlah pesan setiap member

    // Menghitung total pesan untuk setiap member
    for (let id of member) {
        let chatTotal = user[id] ? user[id].chatTotal || 0 : 0; // Ambil total chat, default 0 jika belum ada
        messageCounts.push({ id, chatTotal }); // Menyimpan id dan total pesan
        totalPesan += chatTotal; // Menambahkan total pesan
    }

    // Mengurutkan member berdasarkan jumlah pesan
    messageCounts.sort((a, b) => b.chatTotal - a.chatTotal);

    // Membangun caption berdasarkan urutan yang telah ditentukan
    for (let { id, chatTotal } of messageCounts) {
        mentions.push(id); // Menambahkan member ke array mentions
        caption += `• @${id.split('@')[0]}: ${toRupiah(chatTotal)} pesan\n`; // Format mention
    }

    // Menambahkan jumlah total pesan ke caption
    caption += `\nJumlah semua pesan: ${toRupiah(totalPesan)} pesan`; // Menambahkan total pesan ke caption

    // Mengirim pesan dengan mentions
    await conn.sendMessage(m.chat, {
        text: caption.trim(),
        mentions: mentions
    });
}

handler.help = ['listtotalpesan', 'resetlisttotalpesan'];
handler.tags = ['group'];
handler.command = /^(listtotalpesan|resetlisttotalpesan)$/i; // Memperbaiki regex agar command bisa terdeteksi
handler.group = true;
handler.admin = true

export default handler;

const toRupiah = number => parseInt(number).toLocaleString().replace(/,/gi, ".");