import PhoneNumber from "awesome-phonenumber";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const example = `
Contoh penggunaan:
- ${usedPrefix + command} nomor waktu
- Reply pesan seseorang dengan ${usedPrefix + command} waktu

Contoh:
- ${usedPrefix + command} 6281234567890 30d
- Reply pesan dengan ${usedPrefix + command} 1y

Gunakan:
- d untuk hari (day)
- y untuk tahun (year)
- h untuk jam (hour)
- m untuk menit (minute)
`.trim();

    if (!text && !m.quoted) throw example;

    let who, time;

    // Jika ada text
    if (text) {
        let args = text.split(" ");
        if (args.length === 2) {
            who = args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
            time = args[1];
        } else if (args.length === 1 && m.quoted) {
            who = m.quoted.sender;
            time = args[0];
        } else {
            throw example;
        }
    }

    // Jika hanya reply
    if (!text && m.quoted) {
        who = m.quoted.sender;
        time = text.trim();
    }

    if (!who || !time) throw example;

    const data = (await conn.onWhatsApp(who))?.[0] || {};
    if (!data.exists) throw `Nomor '${PhoneNumber("+" + who.split("@")[0]).getNumber("international")}' tidak terdaftar di WhatsApp!`.trim();

    if (!(who in global.db.data.users)) {
        global.db.data.users[who] = { premium: false, premiumTime: 0 };
    }

    let user = global.db.data.users[who];

    // Konversi waktu ke milidetik
    const timeMap = {
        d: 86400000, // Hari
        y: 31536000000, // Tahun
        h: 3600000, // Jam
        m: 60000 // Menit
    };

    const match = time.match(/^(\d+)([dyhm])$/i);
    if (!match) throw "Format waktu salah! Gunakan d, y, h, atau m.";

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    const timeInMs = value * (timeMap[unit] || 0);

    if (!timeInMs) throw "Format waktu salah atau unit tidak valid!";

    // Tambahkan waktu premium
    const now = Date.now();
    if (now < user.premiumTime) {
        user.premiumTime += timeInMs;
    } else {
        user.premiumTime = now + timeInMs;
    }

    user.premium = true;

    // Simpan ke database
    await global.db.write();

    const remainingTime = user.premiumTime - now;
    const daysLeft = Math.floor(remainingTime / 86400000);
    const hoursLeft = Math.floor((remainingTime % 86400000) / 3600000);

    m.reply(`✔️ *Sukses menambah premium!*
📛 *Nama:* ${user.name ?? await conn.getName(who, true)}
📆 *Waktu Premium:* ${value}${unit} (${daysLeft} hari ${hoursLeft} jam)
📉 *Waktu Berakhir:* ${new Date(user.premiumTime).toLocaleString()}`);
};

handler.help = ['addprem <user waktu>', 'addprem <waktu> (via reply)'];
handler.tags = ['owner'];
handler.command = /^(add|tambah|\+)p(rem)?$/i;

handler.rowner = true;
handler.owner = true;

export default handler;