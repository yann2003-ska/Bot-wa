import fetch from 'node-fetch';

let handler = async (m, { conn, usedPrefix, command, text, isAdmin, isGroup }) => {
    if (!m.isGroup) return m.reply(`❌ Perintah ini hanya bisa digunakan di grup!`);

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    // Inisialisasi database jika belum ada
    chat.warn = chat.warn || {}; // Menyimpan jumlah warning per pengguna
    chat.maxWarn = chat.maxWarn || 5; // Batas maksimal warning default (5)

    let groupMetadata = await conn.groupMetadata(m.chat).catch(() => null);
    if (!groupMetadata) return m.reply(`❌ Gagal mengambil data grup! Pastikan bot memiliki izin membaca grup.`);

    let participants = groupMetadata.participants.map(p => p.id);

    let who = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null);

    switch (command) {
        // --- CEK WARN ---
        case 'cekwarn':
            if (!who) return m.reply(`❌ *Tag atau reply pesan pengguna!* Contoh:\n${usedPrefix + command} @${m.sender.split('@')[0]}`, false, { mentions: [m.sender] });
            if (!participants.includes(who)) return m.reply(`⚠️ *User tersebut tidak ada di grup ini!*`);

            let warnCount = chat.warn[who] || 0;
            let caption = `
📢 *Cek Warning*
👤 *User:* @${who.split('@')[0]}
⚠️ *Jumlah Warn:* ${warnCount}/${chat.maxWarn}
${warnCount === 0 ? '✅ User ini tidak memiliki warn' : `❗ Jika warn mencapai ${chat.maxWarn}, user ini akan dikick!`}
`.trim();
            return conn.sendMessage(m.chat, { text: caption, mentions: [who] }, { quoted: m });

        // --- LIST WARN ---
        case 'listwarn':
            let warnList = Object.entries(chat.warn)
                .filter(([user, count]) => count > 0)
                .map(([user, count], index) => `${index + 1}. @${user.split('@')[0]} → ${count}/${chat.maxWarn} warn`)
                .join('\n');

            let warnMessage = warnList.length > 0 
                ? `📢 *Daftar Pengguna yang Memiliki Warn:*\n\n${warnList}` 
                : `✅ *Tidak ada pengguna yang memiliki warn di grup ini!*`;

            return conn.sendMessage(m.chat, { text: warnMessage, mentions: Object.keys(chat.warn) }, { quoted: m });

        // --- TAMBAH WARN ---
        case 'addwarn':
        case 'warn':
            if (!isAdmin) return m.reply(`❌ *Hanya admin yang dapat menambahkan warn!*`);
            if (!who) return m.reply(`❌ *Tag atau reply pesan pengguna!*`);
            if (!participants.includes(who)) return m.reply(`⚠️ *User tersebut tidak ada di grup ini!*`);

            chat.warn[who] = (chat.warn[who] || 0) + 1;
            if (chat.warn[who] >= chat.maxWarn) {
                await conn.reply(m.chat, `⚠️ *User @${who.split('@')[0]} telah mencapai batas ${chat.maxWarn} warn dan akan dikick!*`, m, { mentions: [who] });
                await conn.groupParticipantsUpdate(m.chat, [who], 'remove');
                chat.warn[who] = 0; // Reset warn setelah dikick
            } else {
                await conn.reply(m.chat, `✅ *Warn ditambahkan!*\n👤 *User:* @${who.split('@')[0]}\n⚠️ *Warning:* ${chat.warn[who]}/${chat.maxWarn}`, m, { mentions: [who] });
            }
            break;

        // --- HAPUS WARN ---
        case 'delwarn':
            if (!isAdmin) return m.reply(`❌ *Hanya admin yang dapat menghapus warn!*`);
            if (!who) return m.reply(`❌ *Tag atau reply pesan pengguna!*`);
            if (!participants.includes(who)) return m.reply(`⚠️ *User tersebut tidak ada di grup ini!*`);
            if (!chat.warn[who] || chat.warn[who] === 0) return m.reply(`⚠️ *User @${who.split('@')[0]} tidak memiliki warn!*`, false, { mentions: [who] });

            chat.warn[who] -= 1;
            return m.reply(`✅ *Warn dikurangi!*\n👤 *User:* @${who.split('@')[0]}\n⚠️ *Warning:* ${chat.warn[who]}/${chat.maxWarn}`, false, { mentions: [who] });

        // --- SET MAX WARN (BISA DIGUNAKAN SEMUA ANGGOTA GRUP) ---
        case 'setmaxwarn':
            let newLimit = parseInt(text);
            if (isNaN(newLimit) || newLimit < 1) return m.reply(`⚠️ *Masukkan angka yang valid untuk batas warn!*\n\nContoh:\n${usedPrefix + command} 5`);
            chat.maxWarn = newLimit;
            return m.reply(`✅ *Batas maksimal warn untuk grup ini telah diubah menjadi ${chat.maxWarn}!*`);
    }
};

handler.help = ['cekwarn', 'listwarn', 'addwarn', 'delwarn', 'setmaxwarn'];
handler.tags = ['group'];
handler.command = /^(cekwarn|listwarn|warn|addwarn|delwarn|setmaxwarn)$/i;
handler.group = true;
handler.admin = /^(warn|addwarn|delwarn)$/i; // Hanya admin yang bisa warn, delwarn

export default handler;