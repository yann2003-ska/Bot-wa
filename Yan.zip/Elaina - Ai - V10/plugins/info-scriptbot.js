import fs from 'fs'

let handler = async (m, { conn }) => {
	let owner = `*Promo Terbatas !* Dapatkan New
Script Elaina - C.Ai V9 
Bot WhatsApp MultiFungsi! Bisa Auto Ai,rpg/game,
brat,sticker,download TikTok,Play YT/Spotify & selesaikan Tugas Sekolahmu Dengan Mudah.Jangan Sampai Ketinggalan! Ayo Beli sekarang...

*ALL FEATURE 490+ BISA CEK SENDIRI DI DALAM GROUP*
https://chat.whatsapp.com/Ip53GWPxq4C7113ehwbzf6

[ *Price : Rp40.000/40K* ]
- Free Update !!!
- Free Panel Unlimited
- Free Pasang & Rename
- Free Apikey Dan Scrape
- No Enc & Anti Error 100%
- *Harga Asli ~60K~* Promo Terbatas 40K Tunggu Apalagi? Ayo Beli Sekarang !!!

*Minat? Chat :* wa.me/6285718275389`;
	await conn.sendMessage(m.chat, { image: { url: './media/thumbnail.jpg' }, caption: owner }, m)
}
handler.help = ['script']
handler.tags = ['owner']
handler.command = /^(script)$/i;

export default handler;