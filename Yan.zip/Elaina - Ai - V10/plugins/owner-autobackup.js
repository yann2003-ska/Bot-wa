import fs from 'fs';
import archiver from 'archiver';
import moment from 'moment-timezone';

const ownerID = '6285718275389@s.whatsapp.net'; // Nomor owner dalam format WhatsApp
let backupInterval = null;
let isBackupActive = false;

// Fungsi untuk menghapus file ZIP lama sebelum backup baru dibuat
function deleteOldBackups() {
  try {
    const existingFiles = fs.readdirSync('.').filter(file => file.endsWith('.zip'));
    for (const file of existingFiles) {
      fs.unlinkSync(file);
      console.log(`🗑️ Backup lama dihapus: ${file}`);
    }
  } catch (err) {
    console.error('❌ Kesalahan saat menghapus backup lama:', err);
  }
}

// Fungsi utama untuk membuat dan mengirim file backup
async function backupAndSend(conn) {
  try {
    deleteOldBackups(); // Hapus file ZIP lama sebelum backup baru

    const timestamp = moment().tz('Asia/Jakarta').format('YYYYMMDD-HH00'); // Format jam penuh
    const waktuBackup = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
    const namabot = 'Bot';
    const backupName = `SC ${namabot} ${timestamp}.zip`;

    const output = fs.createWriteStream(backupName);
    const archive = archiver('zip', { zlib: { level: 9 } });

    archive.pipe(output);

    archive.glob('**/*', {
      cwd: '/home/container',
      ignore: ['node_modules/**', 'sessions/', 'tmp/**', '.npm/**', backupName],
    });

    await archive.finalize();

    output.on('close', async () => {
      const caption = `\`📂 File Backup Bot Otomatis\`\n\n` +
                      `*🗂 Nama File*: ${backupName}\n` +
                      `*📊 Ukuran File*: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB\n` +
                      `*⏰ Waktu Backup*: ${waktuBackup}`;

      // Kirim file ke owner
      if (ownerID) {
        await conn.sendMessage(ownerID, {
          document: { url: backupName },
          mimetype: 'application/zip',
          fileName: backupName,
          caption,
        });
      }

      // Hapus file backup setelah terkirim
      fs.unlinkSync(backupName);
      console.log(`✅ Backup selesai dan file dihapus: ${backupName}`);
    });

    archive.on('error', (err) => {
      console.error('❌ Terjadi kesalahan saat membuat backup:', err);
    });
  } catch (error) {
    console.error('❌ Error pada proses backup:', error);
  }
}

// Fungsi untuk menentukan waktu backup berikutnya dalam 2 jam ke depan
function getNextBackupTime() {
  const now = moment().tz('Asia/Jakarta');
  const nextBackup = now.clone().startOf('hour').add(2 - (now.hour() % 2), 'hours');
  return nextBackup;
}

// Handler utama untuk perintah
const handler = async (m, { conn, command, args }) => {
  const isEnable = /^(on)$/i.test(args[0]);
  const isDisable = /^(off)$/i.test(args[0]);

  switch (command) {
    case 'autobackup':
      if (isEnable) {
        if (isBackupActive) {
          return m.reply('⚠️ *Backup otomatis sudah aktif sebelumnya!*');
        }
        isBackupActive = true;

        // Hitung waktu hingga jadwal backup berikutnya
        const nextBackup = getNextBackupTime();
        const delay = nextBackup.diff(moment().tz('Asia/Jakarta'));

        setTimeout(() => {
          backupAndSend(conn); // Jalankan backup pertama kali pada waktu yang tepat
          backupInterval = setInterval(() => {
            backupAndSend(conn);
          }, 2 * 60 * 60 * 1000); // Setiap 2 jam (7200000 ms)
        }, delay);

        m.reply(`✅ *Backup otomatis telah diaktifkan!*\n📌 *Jadwal*: Setiap 2 jam (00:00, 02:00, 04:00, dst.)`);
      } else if (isDisable) {
        if (!isBackupActive) {
          return m.reply('⚠️ *Backup otomatis tidak aktif.*');
        }
        isBackupActive = false;
        clearInterval(backupInterval);
        m.reply('❌ *Backup otomatis telah dinonaktifkan!*');
      } else {
        m.reply('🛠 *Gunakan perintah berikut:*\n\n- *autobackup on* → Mengaktifkan backup otomatis.\n- *autobackup off* → Menonaktifkan backup otomatis.');
      }
      break;
    default:
      m.reply('❌ *Perintah tidak dikenal!*');
      break;
  }
};

handler.help = ['autobackup'];
handler.tags = ['owner'];
handler.command = /^(autobackup)$/i;
handler.dev = true;

export default handler;