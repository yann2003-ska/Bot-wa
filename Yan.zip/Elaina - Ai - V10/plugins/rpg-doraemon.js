import fetch from 'node-fetch';

let handler = async (m, { conn, args }) => {
    try {
        let user = global.db.data.users[m.sender];
        user.lastDoraemon = user.lastDoraemon || 0;
        let now = new Date() * 1;
        let timeSinceLastAction = now - user.lastDoraemon;

        // Cooldown: 10 minutes
        if (timeSinceLastAction < 600000) {
            return conn.reply(m.chat, `⏳ *Anda harus menunggu ${Math.ceil((600000 - timeSinceLastAction) / 60000)} menit sebelum bermain lagi!*`, m);
        }

        let rewards = [
            { item: 'Pasta Waktu', money: 5000000 },
            { item: 'Senter Tembus Pandang', money: 4000000 },
            { item: 'Baling-Baling Bambu', money: 3500000 },
            { item: 'Kain Pengabul Keinginan', money: 3000000 },
            { item: 'Kantong Ajaib', money: 7000000 },
            { item: 'Mesin Waktu', money: 10000000 }
        ];

        // Randomly decide the outcome
        let outcome = Math.random();
        if (outcome < 0.2) {
            return conn.reply(m.chat, `😔 *Sayang sekali! Anda tidak menemukan apa pun di petualangan ini. Coba lagi nanti!*`, m);
        }

        // Pick a random reward
        let reward = rewards[Math.floor(Math.random() * rewards.length)];

        user.money += reward.money; // Add reward to user's money
        user.lastDoraemon = now; // Update the last action time

        conn.reply(
            m.chat,
            `🎉 *Selamat!* Anda menemukan *${reward.item}* dan mendapatkan Rp ${reward.money.toLocaleString()} 💰!`,
            m
        );
    } catch (e) {
        console.error(e);
        conn.reply(m.chat, `❌ Terjadi kesalahan, coba lagi nanti.`, m);
    }
};

handler.help = ['doraemon'];
handler.tags = ['rpg', 'premium'];
handler.command = /^(doraemon)$/i;

handler.register = true
handler.group = true
handler.premium = true
handler.rpg = true

export default handler;