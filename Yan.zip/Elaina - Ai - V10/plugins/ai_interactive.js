let handler = async (m, { conn, text }) => {
  if (!["on", "off"].includes(text)) return m.reply("on/off?");
  if (!global.ai_interactive) global.ai_interactive = [];

  if (global.ai_interactive.includes(m.chat) && text === "on") return m.reply("Sudah aktif disini!");
  if (!global.ai_interactive.includes(m.chat) && text === "off") return m.reply("Tidak ada sesi chatbot yang aktif disini!");

  text === "on" ? global.ai_interactive.push(m.chat) : global.ai_interactive = global.ai_interactive.filter(a => a !== m.chat);

  m.reply(`Berhasil, Ai interactive ${text}`);
}

handler.help = ["ai_interactive"];
handler.tags = ["ai"];
handler.command = /^(ai_interactive|elaina)$/i;
handler.group = true;
handler.limit = true

export default handler;