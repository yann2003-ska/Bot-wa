import fetch from 'node-fetch';
import request from 'request';
import cheerio from 'cheerio';
import axios from 'axios';
import fs from "fs/promises";

async function getToken(url) {
  try {
    const response = await axios.get(url);
    const cookies = response.headers["set-cookie"];
    const joinedCookies = cookies ? cookies.join("; ") : null;

    const csrfTokenMatch = response.data.match(/<meta name="csrf-token" content="(.*?)">/);
    const csrfToken = csrfTokenMatch ? csrfTokenMatch[1] : null;

    if (!csrfToken || !joinedCookies) {
      throw new Error("Gagal mendapatkan CSRF token atau cookie.");
    }

    return { csrfToken, joinedCookies };
  } catch (error) {
    console.error("❌ Error fetching cookies or CSRF token:", error.message);
    throw error;
  }
}

async function mlStalk(userId, zoneId) {
  try {
    const { csrfToken, joinedCookies } = await getToken("https://www.gempaytopup.com");

    const payload = {
      uid: userId,
      zone: zoneId,
    };

    const { data } = await axios.post(
      "https://www.gempaytopup.com/stalk-ml",
      payload,
      {
        headers: {
          "X-CSRF-Token": csrfToken,
          "Content-Type": "application/json",
          Cookie: joinedCookies,
        },
      }
    );

    return data
  } catch (error) {
    console.error("❌ Error:", error.message);
    console.error("Response:", error.response?.data || "No response data");
  }
}

let handler = async (m, { text, usedPrefix, command }) => {
    const args = text.split(' ');
    if (args.length !== 2) {
        return m.reply(`Masukan ID Mobile Legends dan Zone ID\nContoh: *${usedPrefix + command}* 12345678 2201`);
    }
     conn.sendReact(m.chat, "⏱️", m.key)

    let idML = args[0];
    let zoneId = args[1];

    try {
        let stalkResult = await mlStalk(idML, zoneId);
        m.reply(`*Berikut adalah hasil stalk dari akun Mobile Legend:*\n\n> Nickname: ${stalkResult.username}\n> Region: ${stalkResult.region}`.trim());       
    } catch (error) {
        m.reply(`Error: ${error.message}`);
    }
}

handler.help = ['stalkml <id> <zone id>'];
handler.tags = ['internet'];
handler.command = ['stalkml'];
handler.limit = true;

export default handler;