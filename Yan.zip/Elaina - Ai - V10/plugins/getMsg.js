export async function all(m) {
    let chat = global.db.data.chats[m.chat];
    let user = global.db.data.users[m.sender];

    // Cek apakah pesan berasal dari grup dan bukan dari broadcast atau pengguna yang dibanned
    if (!m.isGroup || m.chat.endsWith('broadcast') || chat.isBanned || user.banned || m.isBaileys) return;

    // Cek apakah pengguna sudah mengirimkan permintaan sebelumnya dalam waktu singkat
    if (chat.lastRequest && Date.now() - chat.lastRequest < 3000) {
        return; // Jika kurang dari 3 detik, jangan lakukan apa-apa
    }

    // Update waktu terakhir permintaan
    chat.lastRequest = Date.now();

    // Cek apakah tipe pesan adalah stiker
    let isSticker = m.mtype === "stickerMessage";
    if (isSticker) return; // Jika pesan adalah stiker, jangan lakukan apa-apa

    // Mencari nilai dalam listStr
    if(!m.text) return
    let [index, value] = Object.entries(chat.store).find(([a, b]) => m.text.toLowerCase().includes(a.toLowerCase())) || [];
    if (!value) return;

    // Serialize pesan yang akan dikirim
    let _m = await this.serializeM(JSON.parse(JSON.stringify(value), (_, v) => {
        if (v !== null && typeof v === 'object' && 'type' in v && Array.isArray(v.data)) {
            return Buffer.from(v.data);
        }
        return v;
    }));

    // Kirim pesan
    await this.sendMessage(m.chat, { forward: _m }, { quoted: m });
}