const { 
    generateWAMessage, 
    STORIES_JID, 
    generateWAMessageFromContent 
} = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, text }) => {
    try {
        let media;
        let content = { caption: text || '#UP STATUS DARI BOT' };

        // Memeriksa apakah ada pesan yang di-quote
        if (m.quoted) {
            // Memeriksa tipe media yang di-quote
            const mime = m.quoted.mimetype || '';
            if (/image|video|audio/.test(mime)) {
                // Mengunduh media
                media = await m.quoted.download();
                if (!media) {
                    return m.reply('Gagal mengunduh media. Silakan coba lagi.');
                }

                // Mengirim informasi tentang media yang diunduh
                const fileType = mime.split('/')[0];
                m.reply(`Berhasil mengunduh media:\n- Tipe: ${fileType}\n- Ukuran: ${media.length} bytes`);

                // Kirim kembali media yang diunduh
                if (fileType === 'image') {
                    content.image = media;
                } else if (fileType === 'video') {
                    content.video = media;
                } else if (fileType === 'audio') {
                    content.audio = media;
                    content.ptt = true;
                    content.mimetype = mime;
                }
            } else {
                return m.reply('Pesan yang di-quote bukan media yang dapat diunduh.');
            }
        } else {
            // Jika tidak ada pesan yang di-quote, gunakan teks yang dikirim
            content.text = text || 'Status tanpa media';
        }

        // Mengirim status ke grup
        const sendStatusMention = async (content, groupData, statusJidList) => {
            let success = 0, failed = 0, index = 0;
            const message = await generateWAMessage(STORIES_JID, content, {
                upload: conn.waUploadToServer,
            });
            const groupStages = itemStages(groupData);

            for (const groupId of groupStages) {
                const additionalNodes = [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: groupId.map((jid) => ({
                            tag: "to",
                            attrs: { jid },
                            content: undefined,
                        })),
                    }],
                }];

                await conn.relayMessage(STORIES_JID, message.message, {
                    messageId: message.key.id,
                    statusJidList,
                    additionalNodes,
                });

                for (const jid of groupId) {
                    try {
                        await conn.sendMessage(jid, { text: 'Lihat nih' }, {
                            quoted: message,
                            ephemeralExpiration: 86400
                        });

                        const msg = await generateWAMessageFromContent(jid, {
                            statusMentionMessage: {
                                message: {
                                    protocolMessage: {
                                        key: message.key,
                                        type: 25,
                                    },
                                },
                            },
                        }, {});

                        await conn.relayMessage(jid, msg.message, {
                            additionalNodes: [{
                                tag: "meta",
                                attrs: { is_status_mention: "true" },
                                content: undefined,
                            }],
                        });
                        success++;
                    } catch (error) {
                        failed++;
                    }

                    index++;
                    const delay = (index % 10 === 0) ? 30000 : 3000;
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
            return { success, failed };
        };

        const groups = Object.values(await conn.groupFetchAllParticipating())
            .filter(v => v.participants.find(p => p.id == conn.user.jid) && !v.announce);
        const groupData = groups.map(x => x.id);
        const statusJidList = groups.flatMap(group => group.participants.map(v => v.id));

        if (groupData.length === 0 || statusJidList.length === 0) {
            return m.reply('Tidak ada grup atau pengguna yang ditemukan untuk mengirim cerita.');
        }

        // Kirim reaksi ke pesan yang di-quote
        await conn.sendMessage(m.chat, {
            react: {
                text: "😂",
                key: m.key
            }
        }, { quoted: m });

        const { success, failed } = await sendStatusMention(content, groupData, statusJidList);

        // Kirim laporan hasil
        conn.reply(m.chat, `Berhasil mengirim cerita ke ${statusJidList.length} user di ${groupData.length} grup.\nSuccess: ${success}${failed > 0 ? '\nFailed: ' + failed : ''}`, m, {
            expiration: 86400
        });
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan, silakan coba lagi.');
    }
};

handler.help = handler.command = ["upswtag"];
handler.tags = ["info"];
handler.mods = true

export default handler;

function itemStages(itemArray) {
    const hasil = [];
    for (let index = 0; index < itemArray.length; index += 5) {
        const stage = itemArray.slice(index, index + 5);
        hasil.push(stage);
    }
    return hasil;
}