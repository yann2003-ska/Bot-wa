import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("masukan prompt");

    try {
        await global.loading(m, conn)
        const {
            data
        } = await axios.get(`https://api.betabotz.eu.org/api/maker/text2img?text=${text}&apikey=ZenOfficial`, {
            responseType: "arraybuffer"
        })
        await conn.sendFile(m.chat, data, "", "Hasil Text2img", m);
    } catch (e) {
        throw e
    } finally {
        await global.loading(m, conn, true)
    }
}
handler.help = handler.command = ['txt2img', 'aiimage', 'aifoto']
handler.tags = ['ai']

export default handler