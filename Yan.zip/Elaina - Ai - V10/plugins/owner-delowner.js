import axios from 'axios';

let handler = async (m, { conn, usedPrefix, command }) => {
  // Ambil target user dari mention atau quoted sender
  let who = m.mentionedJid?.[0] || m.quoted?.sender || '';
  if (!who)
    return m.reply(`Format: ${usedPrefix + command} <tag atau quote user>`);
  
  // Validasi apakah nomor target adalah pengguna WhatsApp
  let meh = await conn.onWhatsApp(who);
  if (meh.length === 0)
    return m.reply(`[!] Failed, @${(who.split('@')[0] || '')} bukan pengguna WhatsApp.`, null, { mentions: [who] });
  
  // Cek agar bot tidak dihapus (bot otomatis owner)
  if (who === conn.user.jid)
    return m.reply(`[!] Nomor Bot sudah otomatis menjadi owner.`);
  
  // Cek apakah user tersebut ada di list owner global.config.owner
  const ownerNumbers = global.config.owner.map(([number]) => number);
  if (!ownerNumbers.includes(who.split('@')[0])) {
    return m.reply(`[!] @${who.split('@')[0]} bukan owner.`, null, { mentions: [who] });
  }
  
  // Hapus user tersebut dari global.config.owner
  global.config.owner = global.config.owner.filter(
    ([number]) => number !== who.split('@')[0]
  );
  
  await conn.reply(m.chat, `Sukses menghapus @${who.split('@')[0]} dari list owner.`, m, { mentions: [who] });
};

handler.help = ['delowner'];
handler.tags = ['owner'];
handler.command = /^delowner$/i;
handler.owner = true;

export default handler;