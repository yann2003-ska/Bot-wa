import fs from "fs"

let resp = "./lib/response/"

export async function before(m) {
  let lists = await fs.readdirSync(resp)
  if(lists.includes(m.text)) {
      let mes = JSON.parse(await fs.readFileSync(resp + m.text))
      let type = Object.keys(mes)[0]
          mes[type].contextInfo = {
              quotedMessage: m.message
              
          }
      await this.relayMessage(m.chat, mes, {})
  }
  return true;
}