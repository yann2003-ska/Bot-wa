import fs from 'fs'

let handler = async (m, { conn }) => {
	let owner = `*_Hallo Kak_*
*_Silakan Pilih Payment Di bawah_*
*_Mau Transfer Lewat Mana, Jangan Lupa Kirim Bukti Nya._*

*Dana :* 085715430424
*Gopay :* 085691419758

*Untuk Qris All Payment Kakak Bisa Scan Foto Di Atas*`;
	await conn.sendMessage(m.chat, { image: { url: './media/qris.jpg' }, caption: owner }, m)
}
handler.help = ['payment']
handler.tags = ['owner']
handler.command = /^(payment)$/i;

export default handler;