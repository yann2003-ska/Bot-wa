import axios from 'axios';
import cheerio from 'cheerio';
import qs from 'querystring';

async function KalCinta(namamu, namadia) {
    try {
        // Ambil halaman utama untuk mendapatkan CSRF token dan cookie
        const refererUrl = 'https://www.meracalculator.com/love/love-calculator.php';
        const initialResponse = await axios.get(refererUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; U; Android 14; in; CPH2641 Build/CPH2641_14.0.1.1404(EX01)) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.0.0 Mobile Safari/537.36'
            }
        });

        // Ambil cookie dari response header
        const cookies = initialResponse.headers['set-cookie'] ? initialResponse.headers['set-cookie'].join('; ') : '';

        // Parsing HTML untuk mendapatkan CSRF token
        const $ = cheerio.load(initialResponse.data);
        const csrfToken = $('meta[name="csrf-token"]').attr('content');

        if (!csrfToken) throw new Error('CSRF token tidak ditemukan');

        // Kirim data dengan CSRF token yang sudah didapat
        const postData = qs.stringify({ YourName: namamu, LoverName: namadia });
        const response = await axios.post(
            'https://www.meracalculator.com/ajaxReqests/love_calculator',
            postData,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept': '*/*',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest',
                    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 14; in; CPH2641 Build/CPH2641_14.0.1.1404(EX01)) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.0.0 Mobile Safari/537.36',
                    'Referer': refererUrl,
                    'Cookie': cookies
                }
            }
        );

        if (!response.data) throw new Error('Respon kosong dari server');

        const hasil = response.data;
        return {
            persentase: hasil.percentage ? `${hasil.percentage}%` : '0%',
            pasangan: hasil.caption_ans ? hasil.caption_ans.replace(/<\/?[^>]+(>|$)/g, "").trim() : 'Tidak diketahui'
        };
    } catch (error) {
        return { error: 'Error mengambil data' };
    }
}

// Handler untuk chatbot atau aplikasi
let handler = async (m, { text, conn }) => {
    let [namamu, namadia] = text.split('|').map(v => v.trim());
    if (!namamu || !namadia) return m.reply('Gunakan format: *kalcinta Namamu | Nama Dia*');

    let hasil = await KalCinta(namamu, namadia);
    if (hasil.error) return m.reply(hasil.error);

    let pesan = `❤️ *Kalkulator Cinta* ❤️\n\n👤 *${namamu}* ❤️ *${namadia}*\n🔢 *Kecocokan:* ${hasil.persentase}\n💌 *Hasil:* ${hasil.pasangan}\n\nCIEEE`;
    await m.reply(pesan);
};

handler.help = ['kalcinta namamu | namadia'];
handler.tags = ['fun'];
handler.command = /^kalcinta$/i;
handler.limit = true;

export default handler;